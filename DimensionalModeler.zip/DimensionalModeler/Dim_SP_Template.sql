/*  ================================================================================================================
    TO DEVELOPERS:

    Use the following sample as a template for creating a stored procedure to load a Dimension table.
    You will only need to update certain sections of the code to customize the stored procedure for your need.

    Update the following:
        - Revision History
        - Stored Procedure Name - including the v_StoredProcedureName variable
        - Section to set Object Names and variables
        - Section to define the Source and Transformation queries
        - Section to create the temporary staging table

    Key Notes:
    - Review the final code and make adjustments as applicable for your table.
    - Make sure you are following the Coding Standards in your development, e.g. naming convention, indentation,
        line lengths (you can use the horizontal lines provided in the comments as a guide to limit the length
        of a line in your code, i.e. 120 characters), etc.
    - Provide as much inline documentation as you can so your code is easy to follow and understand.
    - Ensure the stored procedure does not exceed Snowflake’s recommended 100KB size limit.
    - Strive for cost efficiency in your solution design and coding strategy.

    REMOVE THIS COMMENT BLOCK IN YOUR FINAL VERSION.
    ================================================================================================================
*/
CREATE OR REPLACE PROCEDURE EDW.sp_Load_{object_name} (
    p_SourceDatabaseName    VARCHAR,
    p_BatchLogID            VARCHAR DEFAULT '-1',
    p_PipelineID            VARCHAR DEFAULT '-9999',
    p_StartDateTime         TIMESTAMP_NTZ DEFAULT NULL,
    p_EndDateTime           TIMESTAMP_NTZ DEFAULT NULL,
    p_ProcessDateTime       TIMESTAMP_NTZ DEFAULT SYSDATE()
)
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
/*  -------------------------------------------------------------------------------------------------------------------
    Loads data from a streaming source to a target Silver-layer table.

    PARAMETERS:
    - p_SourceDatabaseName - name of the Source table/view database
    - p_BatchLogID - EDO ADF Run ID for the batch
    - p_PipelineID - EDO ADF Run ID for the pipeline
    - p_StartDateTime - start datetime used to filter the source data for incremental load. This is the
            NextStartDateTimeUTC for the pipeline from the EDO MainControlTable
    - p_EndDateTime - end datetime used to filter the source data for incremental load. This is the earlier value
            between the pipeline NextEndDateTimeUTC from the EDO MainControlTable or the trigger datetime.
    - p_ProcessDateTime - pipeline trigger datetime

    OUTPUT:
    - Audit counts from the load process.

    REVISION HISTORY:  (Retain 1st and last 3 revisions only, remove older revision notes.)
    DATE          | MODIFIED BY         | DESCRIPTION
    Feb 20, 2025  | Tharun K            | Initial creation
    Apr 20, 2025  | E. Lagmay           | Updated code sections and queries.
    -------------------------------------------------------------------------------------------------------------------
*/
DECLARE
    -- Default variables
    v_StoredProcedureName           VARCHAR := 'sp_Load_{object_name}';
    v_ExecutionStartDatetime        TIMESTAMP_NTZ := SYSDATE();
    v_ExecutionEndDatetime          TIMESTAMP_NTZ;
    v_QueryTag                      VARCHAR;
    v_ErrorMessage                  VARCHAR;

    -- Stage data variables
    v_StagingSchemaName             VARCHAR;    -- Schema name where temporary staging table will be created
    v_StagingTableName              VARCHAR;    -- Staging temporary table name
    v_StagingFullTableName          VARCHAR;
    v_BusinessKeyColumnList         VARCHAR;
    v_BusinessKeySortedList         VARCHAR;
    v_Type1ColumnList               VARCHAR;
    v_Type1ColumnSortedList         VARCHAR;
    v_Type2ColumnSortedList         VARCHAR;
    v_DataColumnList                VARCHAR;    -- Table columns, excluding SID and audit columns
    v_AdditionalColumnList          VARCHAR;    -- Audit columns to add to the select list when querying the source

    -- Gold data variables
    v_DimDatabaseName               VARCHAR := CURRENT_DATABASE();
    v_DimSchemaName                 VARCHAR;
    v_DimTableName                  VARCHAR;
    v_CreationDatetimeColumn        VARCHAR;    -- Source columns that will be used to set the values for the
    v_ModificationDatetimeColumn    VARCHAR;    -- __EffectiveStartDatetime and __EffectiveEndDatetime audit columns

    -- Query string variables
    v_SourceQuery                   VARCHAR;
    v_TransformationQuery           VARCHAR;
    v_StagingQuery                  VARCHAR;
    v_DeletedFlagColumnString       VARCHAR;    -- String for including the __DeletedFlag column in the staging query

    -- Audit variables
    v_StagingCount                  NUMBER := 0;
    v_DimBeforeCount                NUMBER := 0;
    v_DimAfterCount                 NUMBER := 0;
    v_LateArrivingUpdateCount       NUMBER := 0;
    v_TypeIUpdateCount              NUMBER := 0;
    v_TypeIIUpdateCount             NUMBER := 0;
    v_TypeIIInsertCount             NUMBER := 0;
    v_NewInsertCount                NUMBER := 0;
    v_AuditData                     VARCHAR;
    v_AuditDataArray                ARRAY;
    v_AuditCountData                VARIANT;

BEGIN
    -- ================================================================================================================
    -- =                                 CONFIGURE SESSION AND INITIALIZE VARIABLES                                   =
    -- ================================================================================================================
  
    -- ----------------------------------------------------------------------------------------------------------------
    -- Set Session Parameters
    -- ----------------------------------------------------------------------------------------------------------------
    -- Get the current Query Tag for the session
    v_QueryTag := (CALL ED_UTILITIES.COMMON.sp_Get_SessionParameter(p_SessionParameter => 'QUERY_TAG'));
   
    -- Set the Quoted Identifiers Ignore Case parameter to the default TRUE setting
    CALL ED_UTILITIES.COMMON.sp_Set_SessionParameter(p_SessionParameter => 'QUOTED_IDENTIFIERS_IGNORE_CASE',
                                                     p_ParameterValue => TRUE);
    -- Set the new Query Tag for the session
    CALL ED_UTILITIES.COMMON.sp_Set_SessionParameter(p_SessionParameter => 'QUERY_TAG',
                        p_ParameterValue => TO_VARIANT(:v_StoredProcedureName || ' - Batch Log ' || :p_BatchLogID));

    -- ----------------------------------------------------------------------------------------------------------------
    -- Set Gold Object Variables
    -- ----------------------------------------------------------------------------------------------------------------
    v_DimSchemaName := '{table_schema}';
    v_DimTableName := '{object_name}';

    -- ----------------------------------------------------------------------------------------------------------------
    -- Set Staging Object Variables
    -- ----------------------------------------------------------------------------------------------------------------
    -- Stage data variables
    v_StagingSchemaName := 'EDWSTAGE'; 
    v_StagingTableName := 'tmp_' || v_DimTableName;
    v_StagingFullTableName := v_StagingSchemaName || '.' || v_StagingTableName;

    -- ----------------------------------------------------------------------------------------------------------------
    -- Set Other Variables
    -- ----------------------------------------------------------------------------------------------------------------
    -- Business key column list
    v_BusinessKeyColumnList := {business_key_columns};
    v_BusinessKeySortedList := (CALL ED_UTILITIES.COMMON.sp_Sort_List(p_List => :v_BusinessKeyColumnList));
    
    -- Type 1 column list
    v_Type1ColumnList := {type_1_columns};
    v_Type1ColumnSortedList := (CALL ED_UTILITIES.COMMON.sp_Sort_List(p_List => :v_Type1ColumnList));

    -- Type 2 column list
    -- The following utility returns all table data columns except those specified in the Type 1 column list above.
    v_Type2ColumnSortedList := (CALL ED_UTILITIES.COMMON.sp_Get_TableTypeIIColumns(
                                        p_DatabaseName => :v_DimDatabaseName,
                                        p_SchemaName => :v_DimSchemaName, 
                                        p_TableName => :v_DimTableName, 
                                        p_TypeIColumnList => :v_Type1ColumnList)); 
    
    -- Add the __DeletedFlag column to to the list so it gets included when calculating the Type2Hash
    v_Type2ColumnSortedList:= v_Type2ColumnSortedList || ', __DeletedFlag';

    -- Additional columns (e.g. audit columns) that need to be added to the source query. 
    v_AdditionalColumnList := '';

    -- Get Target table data columns (excludes SID and audit columns)
    v_DataColumnList := (CALL ED_UTILITIES.COMMON.sp_Get_SelectOrDataColumns(
                                        p_DatabaseName => :v_DimDatabaseName,
                                        p_SchemaName => :v_DimSchemaName,
                                        p_TableName => :v_DimTableName));

    -- The source columns identified v_CreationDatetimeColumn and v_ModificationDatetimeColumn drive the values used
    -- to populate the __EffectiveStartDateime and __EffectiveEndDatetime audit columns of the dimension table.
    -- Normally, there should a datetime column from the source that indicates when the record was created and when it
    -- changed.  If no such column exist, the landing datetime of the record in the Bronze layer is what is used.

    -- Developer Note:
        -- Set 'v_CreationDatetimeColumn' to the name of the source column that records when a record was created.
        -- Set 'v_ModificationDatetimeColumn' to the name of the source column that records when a record was last modified.
    v_CreationDatetimeColumn := '{source_create_datetime_column}'; 
    v_ModificationDatetimeColumn := '{source_update_datetime_column}';

    -- ----------------------------------------------------------------------------------------------------------------
    -- Define Source Query
    -- ----------------------------------------------------------------------------------------------------------------
    -- Define the query used to read data from the source and will be used to populate the temporary staging tables.
    -- "regular_incremental" read mode returns __current = true records only and based on the process start and end
    -- datetime parameters.
    {view_statements}

    -- ----------------------------------------------------------------------------------------------------------------
    -- Define Transformation Query
    -- ----------------------------------------------------------------------------------------------------------------
    -- If the source has a column that indicates the deleted status of a row, make sure to alias the column with
    -- "__Deleted_Flag".
    /* BEGIN CUSTOM TRANSFORMATION */
    v_TransformationQuery := '{custom_transformation}';
    /* END CUSTOM TRANSFORMATION */    

    -- Check if the transformation query already contains the __Deleted_Flag column
    IF (CONTAINS(UPPER(:v_TransformationQuery), '__DELETED_FLAG')) THEN
        v_DeletedFlagColumnString := '__DeletedFlag AS "__DeletedFlag"';
    ELSE
        -- Else assign FALSE as the default value.
        v_DeletedFlagColumnString := '0 AS "__DeletedFlag"';
    END IF;

    -- ================================================================================================================
    -- =                                         CREATE STAGING TABLE                                                 =
    -- ================================================================================================================
{CteSql}
    EXECUTE IMMEDIATE v_StagingQuery;

    -- We need to do the following stpes because the sp_Process_DimTable stored proc requires the audit column names
    -- to match its expected format, including Pascal casing. Snowflake, by default, will create the staging table
    -- above with column names in upper case, unless we change the setting for quoted identifiers to false before
    -- creating the table. However, doing this would require us to enclose column references in double quotes
    -- throughout the entire query. The following is a workaround for now until the sp_Process_DimTable is modified
    -- to remove the exact string comparison for audit columns.
    CALL ED_UTILITIES.COMMON.sp_Set_SessionParameter(p_SessionParameter => 'QUOTED_IDENTIFIERS_IGNORE_CASE',
                                                     p_ParameterValue => FALSE);
    v_StagingQuery := 'BEGIN
                            ALTER TABLE ' || v_StagingFullTableName ||
                                ' RENAME COLUMN __BusinessKeyHash TO "__BusinessKeyHash";
                            ALTER TABLE ' || v_StagingFullTableName ||
                                ' RENAME COLUMN __Type1Hash TO "__Type1Hash";
                            ALTER TABLE ' || v_StagingFullTableName ||
                                ' RENAME COLUMN __Type2Hash TO "__Type2Hash";
                            ALTER TABLE ' || v_StagingFullTableName ||
                                ' RENAME COLUMN __DeletedFlag TO "__DeletedFlag";
                            ALTER TABLE ' || v_StagingFullTableName ||
                                ' RENAME COLUMN __CreateDateTime TO "__CreateDateTime";
                            ALTER TABLE ' || v_StagingFullTableName ||
                                ' RENAME COLUMN __DataCreationDateTime TO "__DataCreationDateTime";
                            ALTER TABLE ' || v_StagingFullTableName ||
                                ' RENAME COLUMN __DataModificationDateTime TO "__DataModificationDateTime";
                        END';
    EXECUTE IMMEDIATE v_StagingQuery;
    CALL ED_UTILITIES.COMMON.sp_Set_SessionParameter(p_SessionParameter => 'QUOTED_IDENTIFIERS_IGNORE_CASE',
                                                     p_ParameterValue => TRUE);

    -- Get Staging records.
    v_StagingCount := (SELECT COUNT(1) FROM IDENTIFIER(:v_StagingFullTableName));

    -- ================================================================================================================
    -- =                                          LOAD DIMENSION TABLE                                                =
    -- ================================================================================================================
    -- IF there is data to load from the staging table, proceed to loading the Dimension table.
    IF (v_StagingCount > 0 ) THEN
        v_AuditData := (CALL EDW.sp_Process_DimTable (
                                StagingSchemaName => :v_StagingSchemaName,
                                StagingTableName => :v_StagingTableName,
                                DimSchemaName => :v_DimSchemaName,
                                DimTableName => :v_DimTableName,
                                TypeIColumnList => :v_Type1ColumnList,
                                ProcessDateTime => :p_ProcessDateTime,
                                BatchLogId => :p_BatchLogID,
                                PipelineId => :p_PipelineID
                        ));

        v_AuditDataArray := (SELECT SPLIT(:v_AuditData,','));
        v_StagingCount := v_AuditDataArray[0];
        v_DimBeforeCount := v_AuditDataArray[1];
        v_LateArrivingUpdateCount := v_AuditDataArray[2];
        v_TypeIUpdateCount := v_AuditDataArray[3];
        v_TypeIIUpdateCount := v_AuditDataArray[4];
        v_TypeIIInsertCount := v_AuditDataArray[5];
        v_NewInsertCount := v_AuditDataArray[6];
        v_DimAfterCount := v_AuditDataArray[7];
    END IF;

    -- ================================================================================================================
    -- =                                              POST-PROCESSING                                                 =
    -- ================================================================================================================
    v_ExecutionEndDatetime := SYSDATE();

    -- Construct JSON object for the audit counts
    v_AuditCountData := OBJECT_CONSTRUCT_KEEP_NULL(
                        'DatabaseName', v_DimDatabaseName,
                        'SchemaName', v_DimSchemaName,
                        'TableName', v_DimTableName,
                        'StoredProcedure', v_StoredProcedureName,
                        'StagingCount', v_StagingCount,
                        'DimBeforeCount', v_DimBeforeCount,
                        'LateArrivingUpdateCount',v_LateArrivingUpdateCount,
                        'TypeIUpdateCount', v_TypeIUpdateCount,
                        'TypeIIUpdateCount', v_TypeIIUpdateCount,
                        'TypeIIInsertCount', v_TypeIIInsertCount,
                        'NewInsertCount', v_NewInsertCount,
                        'DimAfterCount', v_DimAfterCount,
                        'ProcessDatetime', :p_ProcessDateTime,
                        'ExecutionStartDatetime', v_ExecutionStartDatetime,
                        'ExecutionEndDatetime', v_ExecutionEndDatetime
                        );

  -- Log the audit counts into the system event table in PRD.
    IF (CURRENT_DATABASE() = 'SUNCOR') THEN
        CALL ED_UTILITIES.COMMON.sp_Log_SystemEvent(p_SeverityLevel => 'INFO', p_Message => :v_AuditCountData);
    END IF;

    -- Set the session Query Tag back to the previous value. This is needed so that the previous query tag is used for
    -- any subsequent queries, especially if this stored proc was called from a wrapper or another stored procedure. 
    CALL ED_UTILITIES.COMMON.sp_Set_SessionParameter(p_SessionParameter => 'QUERY_TAG',
                    p_ParameterValue =>  TO_VARIANT(:v_QueryTag));
    
    RETURN (v_AuditCountData);

    -- ----------------------------------------------------------------------------------------------------------------
    -- Exception handling - log the error details in the event table and raise the error
    -- ----------------------------------------------------------------------------------------------------------------
    EXCEPTION
        WHEN OTHER THEN
            v_ErrorMessage := 'Error encountered - DatabaseName: ' || v_DimDatabaseName ||
                                    ', SchemaName: ' || v_DimSchemaName || ', TableName: ' || v_DimTableName ||
                                    ', StoredProcedure: ' || v_StoredProcedureName ||
                                    ', SQLCODE: ' || SQLCODE || ', SQLERRM: ' || SQLERRM ||
                                    ', SQLSTATE: ' || SQLSTATE || ', TIMESTAMP : ' || SYSDATE();

            CALL ED_UTILITIES.COMMON.sp_Log_SystemEvent(p_SeverityLevel => 'ERROR', p_Message => :v_ErrorMessage);
            RAISE;
END;
$$;
