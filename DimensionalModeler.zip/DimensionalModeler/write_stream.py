import streamlit as st
import time

def text_stream(text: str, delay_seconds: float = 0.03, pause_seconds: float = 0.05):
    """
    Continuously streams text one character at a time, clears it after finishing,
    and loops indefinitely.

    Parameters:
        text (str): The text string to animate.
        delay_seconds (float): Delay between characters.
        pause_seconds (float): Delay before clearing and moving to next line.
    """

    # Create an empty placeholder for dynamic updates
    placeholder = st.empty()

    lines = text.splitlines()

    while True:
        for line in lines:
            def char_generator():
                for ch in line:
                    yield ch
                    time.sleep(delay_seconds)

            # Display the line character-by-character
            placeholder.write_stream(char_generator, cursor='`●`')

            # Pause before clearing and moving to the next line
            time.sleep(pause_seconds)
        placeholder.empty()

text_stream('Hello World!\nWhat is life!')