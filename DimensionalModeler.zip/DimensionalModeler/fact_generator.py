import pandas as pd
from collections import defaultdict

def wrap_columns(column_string, max_length, indent_size):
    """
    Wraps a comma-separated list of columns so that no line exceeds max_length.
    Each line ends with '||' except the last.
    All lines except the first are indented.
    """
    indent = " " * indent_size
    columns = [col.strip() for col in column_string.split(",")]
    lines = []
    current_line = ""
    for col in columns:
        if current_line:
            test_line = current_line + ", " + col
        else:
            test_line = col
        if len(test_line) > max_length:
            lines.append("'" + current_line + "," + "'" + " ||")
            current_line = col
        else:
            current_line = test_line
    if current_line:
        lines.append("'" + current_line + "'")
    for i in range(1, len(lines)):
        lines[i] = indent + lines[i]
    return "\n".join(lines)


def generate_fact_scripts(sttm, table_description, transformation_query):
    object_name = sttm["Table"].iat[0].upper()
    
    # A list of statements to be generated and merged to generate the sequence file
    sequence_statements = []

    # Variable to be appeneded to generate the DDL Script
    ddl_statements = (
        'ALTER SESSION SET QUOTED_IDENTIFIERS_IGNORE_CASE = FALSE;\n\n' +
        f'CREATE OR ALTER TABLE EDW.{object_name} (\n'
    )

    # Part of the DDL script comment section
    comment_sql = f"ALTER SESSION SET QUOTED_IDENTIFIERS_IGNORE_CASE = TRUE;\n\n"
    table_comment = f'$${table_description}$$' if table_description != '' else f"$$description for table {object_name}$$"
    comment_sql += f"ALTER TABLE EDW.{object_name} SET COMMENT = {table_comment};\n\n"

    for row in sttm.itertuples(index=False):
        if pd.isna(row.Column_Name):
            continue

        source_column = str(row.Stage_Column_Name).strip()
        target_column = str(row.Column_Name).strip()
        description = row.Description if pd.notna(row.Description) else f'description for {target_column}' 
        data_type = str(row.Target_Data_Type).strip()

        if "__" in source_column or "__" in target_column:
            continue

        if data_type == "PK":
            # Generate the Primary Key SID column in the Table DDL
            sid_type = f"NUMBER DEFAULT EDW.SEQ_{object_name}_{target_column}.NEXTVAL NOT NULL"

            # Generates the Sequence Statements for the sequence DDL
            sequence_statement = f'CREATE SEQUENCE IF NOT EXISTS EDW.SEQ_{object_name}_{target_column}\n'
            sequence_statement += f'\tSTART WITH 1\n'
            sequence_statement += f'\tINCREMENT BY 1\n'
            sequence_statement += f'COMMENT = \'FOR TABLE-COLUMN SEQ_{object_name}.{target_column}\';'
            sequence_statements.append(sequence_statement)
            sequence_sid = target_column
        elif data_type == "FK":
            sid_type = "NUMBER NOT NULL"
        else:
            sid_type = data_type

        ddl_statements += f'"{target_column}" {sid_type},\n'

        comment_sql += f"COMMENT ON COLUMN EDW.{object_name}.{target_column} IS $${description}$$;\n\n"

    audit_columns_definitions = (
        '"__FactKeyHash" BINARY(64),\n' + 
        '"__CreatedBatchLogID" VARCHAR(50) COLLATE \'en-ci\',\n' +
        '"__UpdatedBatchLogID" VARCHAR(50) COLLATE \'en-ci\',\n' +
        '"__CreateDateTime" TIMESTAMP_NTZ(9),\n' +
        '"__UpdateDateTime" TIMESTAMP_NTZ(9),\n' +
        '"__DeletedFlag" BOOLEAN'
    )

    audit_column_comments = (
        f'COMMENT ON COLUMN EDW.{object_name}.__FactKeyHash IS \'The fact table primary key data value (string of characters) for a row of data, transformed into a shorter, fixed-length value or key that represents and makes it easier to find or employ the original string.\';\n\n' + 
        
        f'COMMENT ON COLUMN EDW.{object_name}.__CreatedBatchLogID IS \'The identifying characters of the data batch that contained and generated (created) the row of data\';\n\n' +

        f'COMMENT ON COLUMN EDW.{object_name}.__UpdatedBatchLogID IS \'The identifying characters of the data batch that contained updates to an existing row of data\';\n\n' +

        f'COMMENT ON COLUMN EDW.{object_name}.__CreateDateTime IS \'The date and time that the row of data was created in the EDW\';\n\n' +

        f'COMMENT ON COLUMN EDW.{object_name}.__UpdateDateTime IS \'The date and time that the row of data was updated in the EDW\';\n\n' +

        f'COMMENT ON COLUMN EDW.{object_name}.__DeletedFlag IS \'The row of data for that has been superseded by subsequent updates to a specific column data value\';'
    )

    ddl_statements = ddl_statements.rstrip(',\n') + ',\n' + audit_columns_definitions
    # Ending Parenthesis
    ddl_statements += '\n);\n'

    ddl = ddl_statements + '\n' + comment_sql + audit_column_comments
    sequence = '\n'.join(sequence_statements)

    # -------------------------------
    # Stored Procedure
    # -------------------------------
    business_key_columns = []
    update_table_columns = []
    
    view_statements = []
    processed_views = []
    source_query_statement = []
    cte_statements = []

    select_statements = []
    join_alias_counter = defaultdict(int)
    join_clauses_list = []


    for row in sttm.itertuples(index=False):
        # Generate View Statements
        if pd.notna(row.Schema) and pd.notna(row.ViewName):
            # Check if the same view has already been processed to ignore duplicate sources
            view_already_processed = False
            for view in processed_views:
                if f'{row.Schema}.{row.ViewName}' == view:
                    view_already_processed = True
                    break
            
            if not view_already_processed:
                view_statements.append(f'\n    LET v_SourceQuery_{row.ViewName} VARCHAR; ')

                # Generate Source Query Statements
                if str(row.Schema).strip() == "EDW":
                    p_DatabaseNamevalue = "v_FactDatabaseName"
                else:
                    p_DatabaseNamevalue = "p_SourceDatabaseName"
                
                data_read_type = row.Data_Read_Type if pd.notna(row.Data_Read_Type) else 'type_i_full_load'

                if data_read_type == 'type_i_full_load':
                    source_query_statement.append(f"""
        v_SourceQuery_{row.ViewName} := (CALL ED_UTILITIES.COMMON.sp_Generate_SourceSelectQuery(
                                                            p_DatabaseName => :{p_DatabaseNamevalue},
                                                            p_SchemaName => '{row.Schema}',
                                                            p_ObjectName => '{row.ViewName}',
                                                            p_DataReadType => 'type_i_full_load'));\n""")
                                                            
                elif data_read_type == 'type_ii_incremental_join_right_side':
                    source_query_statement.append(f"""
        v_SourceQuery_{row.ViewName} := (CALL ED_UTILITIES.COMMON.sp_Generate_SourceSelectQuery (
                                                                p_DatabaseName => :{p_DatabaseNamevalue},
                                                                p_SchemaName => '{row.Schema}',
                                                                p_ObjectName => '{row.ViewName}',
                                                                p_DataReadType => 'type_ii_incremental_join_right_side'));\n""")
                
                elif data_read_type == 'type_i_incremental_join_right_side':
                    source_query_statement.append(f"""
        v_SourceQuery_{row.ViewName} := (CALL ED_UTILITIES.COMMON.sp_Generate_SourceSelectQuery (
                                                                p_DatabaseName => :{p_DatabaseNamevalue},
                                                                p_SchemaName => '{row.Schema}',
                                                                p_ObjectName => '{row.ViewName}',
                                                                p_DataReadType => 'type_i_incremental_join_right_side',
                                                                p_ListOfPartitionValues => :v_ListOfPartitionValues));\n""")
                
                else:
                    source_query_statement.append(f"""
        -- ERROR: Unsupported DataReadType '{data_read_type}' for view '{row.ViewName}'
                """)
                    
                if pd.notna(row.Alias):
                    cte_statements.append(f"{row.Alias} AS ('|| v_SourceQuery_{row.ViewName} ||')")
                else:
                    cte_statements.append(f"{row.ViewName} AS ('|| v_SourceQuery_{row.ViewName} ||')")

                processed_views.append(f'{row.Schema}.{row.ViewName}')
            
        if pd.isna(row.Column_Name):
            continue

        # Retrieve Business Key Columns from the STTM
        if str(row.Business_Key).strip().upper() == 'Y' and str(row.Target_Data_Type).strip().upper() != 'PK':
            business_key_columns.append(row.Stage_Column_Name)

        # Retrieve update table Columns from the STTM
        if not row.Column_Name.startswith("__") and row.Target_Data_Type != 'PK' and "SID" not in row.Column_Name:
            update_table_columns.append(row.Column_Name)

        # Generate Select and Join Statements
        base_indent = " " * 36
        deeper_indent = " " * 40
        if pd.notna(row.ParentTableName) and pd.notna(row.ParentColumnName) and pd.notna(row.ParentTableSID):
            # If the same dimention is used multiple times, 
            # from the second occurance it names the alias like DimDate_2
            join_alias_counter[row.ParentTableName] += 1
            alias = row.ParentTableName if join_alias_counter[row.ParentTableName] == 1 else f"{row.ParentTableName}_{join_alias_counter[row.ParentTableName]}"

            select_statements.append(
                f'{" " * 36}CASE WHEN stg.{row.Stage_Column_Name} IS NOT NULL AND\n' +
                f'{" " * 47}{alias}.{row.ParentTableSID} IS NULL THEN -3\n' +
                f'{" " * 44}ELSE COALESCE({alias}.{row.ParentTableSID}, -1)\n' +
                f'{" " * 36}END AS {row.Column_Name}'
            )

            join_lines = [
                base_indent + f"LEFT JOIN {row.TableSchemaName}.{row.ParentTableName} as {alias}",
                deeper_indent + f"ON stg.{row.Stage_Column_Name} = {alias}.{row.ParentColumnName}"
            ]

            # Only add these lines if not DimDate
            if row.ParentTableName.lower() != "dimdate":
                join_lines.append(deeper_indent + f"AND {alias}.__CurrentFlag = TRUE")
                join_lines.append(deeper_indent + f"AND {alias}.__DeletedFlag = FALSE")
            join_clause = "\n".join(join_lines)
            join_clauses_list.append(join_clause)

        else:
            # If it's not a dim column just add stg.Column_Name
            if "__" not in row.Stage_Column_Name and "__" not in row.Column_Name and row.Target_Data_Type != "PK":
                if row.Stage_Column_Name == row.Column_Name:
                    select_statements.append(f"{base_indent}stg.{row.Column_Name}")
                else:
                    select_statements.append(f"{base_indent}stg.{row.Stage_Column_Name} AS {row.Column_Name}") 

    business_key_columns = ', '.join(business_key_columns) if business_key_columns else 'NULL'
    update_table_columns = ', '.join(update_table_columns) if update_table_columns else 'NULL'
    
    view_statements_str = '\n'.join(view_statements + source_query_statement)
    wrapped_cte = f',\n{" " * 21}'.join(cte_statements)

    cte_sql = f'''
    v_SourceDatasetQuery := 'CREATE OR REPLACE TEMPORARY TABLE ' || v_SourceStagingFullTableName || ' AS (
                WITH {wrapped_cte},
                    TransformationQuery AS ( ' || v_TransformationQuery || ')
                SELECT *,
                    SYSDATE() AS __CreateDateTime,
                    ' || v_DeletedFlagColumnString || ',
                    ED_UTILITIES.COMMON.fn_Calculate_Hash(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(' ||
                            v_BusinessKeySortedList || '), ''|'')) AS "__FactKeyHash"
            FROM   TransformationQuery)';
    '''
    
    select_statement = select_statements[0].lstrip() + ',\n' + ',\n'.join(select_statements[1:])
    TempInsert_SQL = (
    "'INSERT INTO ' || v_FactStagingFullTableName || \n"
    + " " * 26 + f"' SELECT {select_statement},\n"
    + " " * 36 + "stg.__FactKeyHash,\n"
    + " " * 36 + "''' || :p_BatchLogID || '''  AS __CreatedBatchLogID,\n"
    + " " * 36 + "''' || :p_BatchLogID || '''  AS __UpdatedBatchLogID,\n"
    + " " * 36 + "stg.__CreateDateTime,\n"
    + " " * 36 + "CAST(''' || :p_ProcessDateTime || ''' AS TIMESTAMP_NTZ) AS __UpdateDateTime,\n"
    + " " * 36 + "stg.__DeletedFlag\n"
    + " " * 26 + "    FROM  ' || v_SourceStagingFullTableName || ' AS stg\n"
    + "\n".join(join_clauses_list) + "'"
)

    sequence_file_name = f'R__000_EDW_SEQ_{object_name}_{sequence_sid}.sql'
    ddl_file_name = f'R__040_EDW_{object_name}.sql'
    sp_file_name = f'R__100_EDW_SP_LOAD_{object_name}.sql'
    
    # Generate Return Values -
    with open('Fact_SP_Template.sql', 'r') as file:
        sp_template = file.read()

    sp = sp_template.format(
        object_name = object_name,
        table_schema = sttm["TableSchemaName"].iat[0].upper(),
        sid_value = sequence_sid,
        business_key_columns = wrap_columns(business_key_columns, max_length=90, indent_size=31),
        update_table_cols = wrap_columns(update_table_columns, max_length=85, indent_size=26),
        view_statements = view_statements_str,
        cte_sql = cte_sql,
        insert_statement = TempInsert_SQL,
        custom_transformation = transformation_query,
    )

    return (sequence_file_name, sequence), (ddl_file_name, ddl), (sp_file_name, sp)