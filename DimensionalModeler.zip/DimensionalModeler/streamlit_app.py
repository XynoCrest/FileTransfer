import io
import re
import time
import base64
import zipfile
import pandas as pd
import streamlit as st
from io import BytesIO
from io import StringIO
from datetime import datetime
from collections import Counter
import traceback

from fact_generator import generate_fact_scripts
from dim_generator import generate_dim_scripts
from internal_libraries.code_editor import code_editor
from session_initializer import retrieve_session, retrieve_deployment_session

# -----------------------------------------
# Page Layout Settings
# -----------------------------------------
st.set_page_config(layout="wide")
st.markdown(
    """
    <style>
    [data-testid="stAppViewContainer"] > .main, 
    [data-testid="stMainBlockContainer"] {
        padding-top: 1.8rem !important;
    }
    [data-testid="stMainBlockContainer"] {
        margin-top: 0rem !important;
    }
    </style>
    """,
    unsafe_allow_html=True
)


# -----------------------------------------
# CUSTOMIZABLE SESSION STATE VARIABLES
# -----------------------------------------
if 'global_save_table' not in st.session_state:
    st.session_state.global_save_table = 'PRJ_COSTTRANSPARENCY_DEV.STREAMLIT.ST_GLOBALSAVE'

# -----------------------------------------
# Session states variable Initialization
# -----------------------------------------
if 'snowpark_session' not in st.session_state:
    st.session_state.snowpark_session = retrieve_session()

if 'reupload_notifs' not in st.session_state:
    st.session_state.reupload_notifs = False

if "is_fact" not in st.session_state:
    st.session_state.is_fact = False

if "is_dim" not in st.session_state:
    st.session_state.is_dim = False

if 'sttm_df' not in st.session_state:
    st.session_state.sttm_df = None

if 'source_df' not in st.session_state:
    st.session_state.source_df = None

if 'dim_df' not in st.session_state:
    st.session_state.dim_df = None

if 'table_name' not in st.session_state:
    st.session_state.table_name = None

# A copy of the Database Column within Sources DF
if 'source_df_databases' not in st.session_state:
    st.session_state.source_df_databases = None

# A copy of the Database Column within Dim DF
if 'dim_df_databases' not in st.session_state:
    st.session_state.dim_df_databases = None

# A Boolean Flag to control the trigger of a script reload 
# after the database in the source_df has been updated through source_df data editor
if 'update_source_df' not in st.session_state:
    st.session_state.update_source_df = False

# A Boolean Flag to control the trigger of a script reload 
# after the database in the dim_df has been updated through dim_df data editor
if 'update_dim_df' not in st.session_state:
    st.session_state.update_dim_df = False

if 'transformation_query' not in st.session_state:
    st.session_state.transformation_query = None

if 'table_description' not in st.session_state:
    st.session_state.table_description = None

# A Boolean Flag - indicates whether scripts have already been generated
if 'scripts_generated' not in st.session_state:
    st.session_state.scripts_generated = False

# Boolean Flags to retrigger script generation after you have already generated scripts the first time and then updated values like the transformation query and reclicked the generate button
if 'retrigger_script_generation' not in st.session_state:
    st.session_state.retrigger_script_generation = False

if 'regenerate_scripts' not in st.session_state:
    st.session_state.regenerate_scripts = False

if 'show_save_success' not in st.session_state:
    st.session_state.show_save_success = False

if 'transformation_query_code_editor_id' not in st.session_state:
    st.session_state.transformation_query_code_editor_id = None

if 'sequence_code_editor_id' not in st.session_state:
    st.session_state.sequence_code_editor_id = None

if 'ddl_code_editor_id' not in st.session_state:
    st.session_state.ddl_code_editor_id = None

if 'dataseed_code_editor_id' not in st.session_state:
    st.session_state.dataseed_code_editor_id = None

if 'sp_code_editor_id' not in st.session_state:
    st.session_state.sp_code_editor_id = None

if 'script_reinitiate' not in st.session_state:
    st.session_state.script_reinitiate = True

if 'recalculate_project_database_index' not in st.session_state:
    st.session_state.recalculate_project_database_index = False

if 'project_database_index' not in st.session_state:
    st.session_state.project_database_index = 0

if 'notify_successful_load' not in st.session_state:
    st.session_state.notify_successful_load = False

if 'examine_uploaded_file' not in st.session_state:
    st.session_state.examine_uploaded_file = False

if 'uploaded_sttm' not in st.session_state:
    st.session_state.uploaded_sttm = None

if 'load_route' not in st.session_state:
    st.session_state.load_route = False

if 'overwrite_save' not in st.session_state:
    st.session_state.overwrite_save = False

if 'validate_query' not in st.session_state:
    st.session_state.validate_query = False

if 'generate_script' not in st.session_state:
    st.session_state.generate_script = False

if 'show_delete_state_status_message' not in st.session_state:
    st.session_state.show_delete_state_status_message = False

if 'persisted_validation_result' not in st.session_state:
    st.session_state.persisted_validation_result = False

if 'extra_columns_in_result' not in st.session_state:
    st.session_state.extra_columns_in_result = None

if 'extra_columns_in_sttm' not in st.session_state:
    st.session_state.extra_columns_in_sttm = None

if 'datatype_mismatch_df' not in st.session_state:
    st.session_state.datatype_mismatch_df = pd.DataFrame([])

if 'sequence_file_name' not in st.session_state:
    st.session_state.sequence_file_name = None

if 'sequence_code' not in st.session_state:
    st.session_state.sequence_code = None

if 'ddl_file_name' not in st.session_state:
    st.session_state.ddl_file_name = None

if 'ddl_code' not in st.session_state:
    st.session_state.ddl_code = None

if 'dataseed_file_name' not in st.session_state:
    st.session_state.dataseed_file_name = None

if 'dataseed_code' not in st.session_state:
    st.session_state.dataseed_code = None

if 'sp_file_name' not in st.session_state:
    st.session_state.sp_file_name = None

if 'sp_code' not in st.session_state:
    st.session_state.sp_code = None

# -------------------
# Callback Functions
# -------------------
def full_reload_source_df():
    '''Initiates a Full Reload of the Source DF in the next Script Reload'''
    st.session_state.source_df = None
    st.session_state.source_df_databases = None


def reload_dim_df():
    '''Initiates a Reload of the Dim DF in the next Script Reload to Facilitate a project database change'''
    st.session_state.dim_df = None
    st.session_state.dim_df_databases = None


def sttm_changed_reload():
    '''Initiates a Reload of the Source DF and Dim DF preserving their Database Column'''
    if st.session_state.source_df is not None and 'Database' in st.session_state.source_df.columns:
        st.session_state.source_df_databases = st.session_state.source_df['Database']
    
    if st.session_state.dim_df is not None and 'Database' in st.session_state.dim_df.columns:
        st.session_state.dim_df_databases = st.session_state.dim_df['Database']
    
    st.session_state.source_df = None
    st.session_state.dim_df = None


def intiate_source_df_db_col_update():
    '''
    Flips a Boolean Flag to trigger a Script Reload after the reassignment
    of source_df to an updated_df after user updates a database value within the source_df
    '''
    st.session_state.update_source_df = True


def intiate_dim_df_db_col_update():
    '''
    Flips a Boolean Flag to trigger a Script Reload after the reassignment
    of dim_df to an updated_df after user updates a database value within the dim_df
    '''
    st.session_state.update_dim_df = True

def trigger_overwrite_save():
    st.session_state.overwrite_save = True

def trigger_query_validation():
    st.session_state.validate_query = True

def trigger_script_generation():
    st.session_state.generate_script = True


def close_manage_saves(item_name):
    st.session_state.current_delete_item = item_name
    st.session_state.show_manage_saves = False
    st.session_state.show_delete_state_status_message = False

def open_manage_saves():
    st.session_state.show_manage_saves = True
    st.session_state.show_delete_state_status_message = False


# -------------------
# Query Functions
# -------------------
def get_database_list():
    data = st.session_state.snowpark_session.sql("SHOW DATABASES").collect()
    databases = [row['name'] for row in data]
    try:
        ed_source_dev_index = databases.index('ED_SOURCE_DEV')
    except:
        ed_source_dev_index = 0
    return databases, ed_source_dev_index

def get_schema_list(database):
    data = st.session_state.snowpark_session.sql(f"SHOW SCHEMAS IN DATABASE {database}").collect()
    schemas = [row['name'] for row in data]
    return schemas
    
def validate_source(database, schema, table):
    query = f'''
    SELECT *
    FROM {database}.{schema}.{table} LIMIT 1'''
    st.code(query, language="sql", line_numbers=True)
    try:
        result = st.session_state.snowpark_session.sql(query)
        if result.columns:
            return True
        else:
            return False
    except:
        return False

def validate_all_sources(df):
    with selected_sources_widget:
        with st.status("Validating Sources..."):
            with st.spinner("Executing Queries in Snowflake", show_time=True):
                with st.empty():
                    validation_results = []
                    for _, row in df.iterrows():
                        db = row['Database']
                        schema = row['Schema']
                        view = row['ViewName']
                        is_valid = validate_source(db, schema, view)
                        emoji = "✅" if is_valid else "❌"
                        validation_results.append(emoji)
    return validation_results

def validate_all_sources_for_subsequent_reruns(df):
    with st.session_state.sources_validator_status:
        with st.status("Validating Sources..."):
            with st.spinner("Executing Queries in Snowflake", show_time=True):
                with st.empty():
                    validation_results = []
                    for _, row in df.iterrows():
                        db = row['Database']
                        schema = row['Schema']
                        view = row['ViewName']
                        is_valid = validate_source(db, schema, view)
                        emoji = "✅" if is_valid else "❌"
                        validation_results.append(emoji)
    with st.session_state.sources_validator_status:
        st.empty()
    return validation_results

def validate_dim(database, table, colName, sidName):
    query = f'''
    SELECT *
    FROM {database}.EDW.{table} LIMIT 1'''
    st.code(query, language="sql", line_numbers=True)
    try:
        result = st.session_state.snowpark_session.sql(query)
        if f"\"{colName}\"" in result.columns and f"\"{sidName}\"" in result.columns:
            return True
        else:
            return False
    except:
        return False

def validate_all_dims(df):
    with joined_dimension_widget:
        with st.status("Validating Dimensions..."):
            with st.spinner("Executing Queries in Snowflake", show_time=True):
                with st.empty():
                    validation_results = []
                    for _, row in df.iterrows():
                        db = row['Database']
                        table = row['ParentTableName']
                        colName = row['ParentColumnName']
                        sidName = row['ParentTableSID']
                        is_valid = validate_dim(db, table, colName, sidName)
                        emoji = "✅" if is_valid else "❌"
                        validation_results.append(emoji)
    return validation_results

def validate_all_dims_for_subsequent_reruns(df):
    with st.session_state.dimension_validator_status:
        with st.status("Validating Dimensions..."):
            with st.spinner("Executing Queries in Snowflake", show_time=True):
                with st.empty():
                    validation_results = []
                    for _, row in df.iterrows():
                        db = row['Database']
                        table = row['ParentTableName']
                        colName = row['ParentColumnName']
                        sidName = row['ParentTableSID']
                        is_valid = validate_dim(db, table, colName, sidName)
                        emoji = "✅" if is_valid else "❌"
                        validation_results.append(emoji)
    with st.session_state.dimension_validator_status:
        st.empty()
    return validation_results

def delete_state(state_name):
    try:
        with st.session_state.delete_confirmation_bottom_container.status('Deleting State'):
            with st.spinner("Executing Queries in Snowflake", show_time=True):
                query = f"DELETE FROM {st.session_state.global_save_table} WHERE SaveName = '{state_name}';"
                st.session_state.snowpark_session.sql(query).collect()
        st.session_state.show_delete_state_status_message = True
        st.session_state.save_list = load_save_list()
        st.session_state.delete_confirmation_bottom_container.success(f'Successfully Deleted **{state_name}**', icon=':material/check:')
        time.sleep(1)
        st.session_state.show_manage_saves = True
    except Exception as e:
        with st.session_state.delete_confirmation_bottom_container.container():
            st.session_state.show_delete_state_status_message = True
            display_error(e, 'Delete Failed')


def get_user_role_list():
    '''Get a list of Roles for the Current User'''
    result = st.session_state.snowpark_session.sql('SELECT CURRENT_USER()').collect()
    user = result[0]["CURRENT_USER()"]
    
    grants = st.session_state.snowpark_session.sql(f'SHOW GRANTS TO USER "{user}"').collect()
    grants_dataframe = pd.DataFrame([r.as_dict() for r in grants])
    roles = (
        grants_dataframe.loc[grants_dataframe['granted_on'] == 'ROLE', 'role']
        .apply(lambda r: r.strip('"'))
        .tolist()
    )
    return roles

def get_role_for_database_selected():
    '''Get the Project Role with access to the Current Project Database'''
    grants = st.session_state.snowpark_session.sql(
        f'SHOW GRANTS ON DATABASE "{st.session_state.project_database}"'
    ).collect()

    grantee_names = [r.as_dict().get("grantee_name") for r in grants if r.as_dict().get("grantee_name")]

    database_roles = list({
        g for g in grantee_names if "PRJ" in g
    })

    user_roles = get_user_role_list()
    roles = list(set(database_roles) & set(user_roles))
    return roles[0]

# --------------------
# Validation Functions
# --------------------
def validate_sttm_schema():
    df = st.session_state.sttm_df
    dim_columns = ['Project', 'TableSchemaName', 'Table', 'Schema', 'ViewName', 'Alias', 'Column_Name', 'Description', 'Target_Data_Type', 'Business_Key', 'Type1Col', 'Mandatory', 'Data_Read_Type', 'SourceDatetimeColumn', 'Table Description', 'Source_Create_Datetime_Column', 'Source_Update_Datetime_Column']

    fact_columns = ['Project', 'TableSchemaName', 'Table', 'Schema', 'ViewName', 'Alias', 'Stage_Column_Name', 'Column_Name', 'Description', 'Target_Data_Type', 'Data_Read_Type', 'Business_Key', 'ParentTableName', 'ParentColumnName', 'ParentTableSID']

    if set(dim_columns).issubset(df.columns):
        return 'DIM'
    
    if set(fact_columns).issubset(df.columns):
        return 'FACT'
    
    return None


# -------------------
# UI Functions
# -------------------
def display_error(error, error_definition, icon=':material/emergency_home:'):
    '''
    Only Show important part of the Error

    Example - 
    Original Error - (1304): 01c0642e-0107-47be-0002-24723bcb02aa: 090236 (42601): Stored procedure execution error: Unsupported statement type 'ALTER_SESSION'.

    Displayed Error - [error_definition]: Stored procedure execution error: Unsupported statement type 'ALTER_SESSION'.
    '''
    e = str(error)
    idx = e.rfind("):")
    if idx != -1:
        error_message = e[idx+2:].strip()
    else:
        error_message = e
    st.error(f'**{error_definition}**: {error_message}', icon=icon) 


def dynamic_input_data_editor(data, key, **_kwargs):
    """
    Like streamlit's data_editor but which allows you to initialize the data editor with input arguments that can
    change between consecutive runs. Fixes the problem described here: https://discuss.streamlit.io/t/data-editor-not-changing-cell-the-1st-time-but-only-after-the-second-time/64894/13?u=ranyahalom
    :param data: The `data` argument you normally pass to `st.data_editor()`.
    :param key: The `key` argument you normally pass to `st.data_editor()`.
    :param _kwargs: All other named arguments you normally pass to `st.data_editor()`.
    :return: Same result returned by calling `st.data_editor()`
    """
    changed_key = f'{key}_khkhkkhkkhkhkihsdhsaskskhhfgiolwmxkahs'
    initial_data_key = f'{key}_khkhkkhkkhkhkihsdhsaskskhhfgiolwmxkahs__initial_data'

    def on_data_editor_changed():
        if 'on_change' in _kwargs:
            args = _kwargs['args'] if 'args' in _kwargs else ()
            kwargs = _kwargs['kwargs'] if 'kwargs' in _kwargs else  {}
            _kwargs['on_change'](*args, **kwargs)
        st.session_state[changed_key] = True

    if changed_key in st.session_state and st.session_state[changed_key]:
        data = st.session_state[initial_data_key]
        st.session_state[changed_key] = False
    else:
        st.session_state[initial_data_key] = data
    __kwargs = _kwargs.copy()
    __kwargs.update({'data': data, 'key': key, 'on_change': on_data_editor_changed})
    return st.data_editor(**__kwargs)


@st.dialog(" ", width='small', on_dismiss=open_manage_saves)
def manage_saves_dialog():
    saves_dialog = st.empty()

    if 'show_manage_saves' not in st.session_state:
        st.session_state.show_manage_saves = True

    if st.session_state.show_manage_saves:
        css = """
            div[aria-modal="true"][aria-label="dialog"][role="dialog"] {
            margin-top: 15vh;
        }
        """
        st.html(f"<style>{css}</style>")

        with saves_dialog.container():
            st.title(':red[:material/save_as: MANAGE SAVES]')
            st.write('`SCROLL DOWN ↓ TO SEE MORE SAVED STATES`')
            
            # Search Bar
            with st.container(border=False, gap=None):
                col1, _ = st.columns([50,1], gap=None)
                with col1:
                    search_string = st.text_input('Search States', icon=':material/search:', label_visibility='collapsed', placeholder='Search for States')
                    if search_string != '':
                        manage_save_list = [
                            item.SAVENAME
                            for item in st.session_state.save_list
                            if search_string.lower() in item.SAVENAME.lower()
                        ]
                    else:
                        manage_save_list = [item.SAVENAME for item in st.session_state.save_list]
            
            # Containers with Saves
            with st.container(height=240, border=False):
                for item in manage_save_list:
                    # Styling for the container
                    backgroundColor = '''{
                            background-color: rgba(26, 28, 36);
                            border-radius: 10px;
                            padding: 0.75rem;
                        }
                    '''
                    css = f"""
                        .st-key-{item.replace(" ", "")} {backgroundColor}
                    """
                    st.html(f"<style>{css}</style>")
                    
                    with st.container(vertical_alignment='center', key=item.replace(" ", "")):
                        col1, col2 = st.columns([12,2], gap = 'small')
                        with col1:
                            st.code(item)
                        with col2:
                            # Styling for the Delete Button
                            backgroundColor = '''{
                                    background-color: rgba(26, 28, 36);
                                    border-radius: 10px;
                                    padding-bottom: 0.5rem;
                                    padding-top: 0.4rem;
                                    color: rgba(255, 108, 108);
                                }
                            '''
                            css = f"""
                                .st-key-{item.replace(" ", "")}-buttonContainer {backgroundColor}
                            """
                            st.html(f"<style>{css}</style>")
                            
                            with st.container(key=f'{item.replace(" ", "")}-buttonContainer', vertical_alignment='center', horizontal_alignment='center'):
                                st.button(
                                    '', 
                                    key=f'{item.replace(" ", "")}_deleteButton', 
                                    icon=':material/delete:', 
                                    type='tertiary', 
                                    on_click=close_manage_saves,
                                    args=(item,)
                                )

            st.caption('Deletes are PERMENANT and cannot be reversed! Proceed with Caution!')
            st.write(' ')
    else:
        css = """
            div[aria-modal="true"][aria-label="dialog"][role="dialog"] {
            margin-top: 25vh;
        }
        """
        st.html(f"<style>{css}</style>")

        with saves_dialog.container():
            st.html(f"""
                <div style="text-align: center; font-family: sans-serif;">
                    <div style="
                        width: 50px;
                        height: 50px;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        margin: 0 auto 0;
                    ">
                        <span style="color: #ff4d4d; font-size: 36px;">⚠️</span>
                    </div>
                    
                    <h2 style="margin: 0 0 10px 0; color: #faf9f9; font-size: 28px; font-weight: 700;">
                        Are you sure?
                    </h2>
                    
                    <p style="margin: 0; color: #888; font-size: 16px; line-height: 1.5;">
                        Are you sure you want to delete <span style="color: #ff6c5f;">{st.session_state.current_delete_item}</span><br>
                        This action cannot be undone!
                    </p>
                </div>
            """)

            st.write(" ")

            if not st.session_state.show_delete_state_status_message:
                st.session_state.delete_confirmation_bottom_container = st.empty()
                with st.session_state.delete_confirmation_bottom_container.container():
                    col1, col2 = st.columns([5,5])
                    with col1:
                        st.button(
                            "Delete State", 
                            icon=':material/delete_forever:',
                            use_container_width=True,
                            on_click=delete_state,
                            args=(st.session_state.current_delete_item,)
                        )
                        
                    with col2:
                        st.button(
                            "Cancel",
                            icon=':material/close:',
                            use_container_width=True, 
                            on_click=open_manage_saves, 
                        )

# -------------------
# Utility Functions
# -------------------
def string_splitter(input_string):
    """
    Split a string on semicolons (;) that are *outside* math blocks delimited
    by double dollar signs ($$...$$).

    Used to Split the Table DDL code into multiple queries
    """
    result = []
    pos = 0
    pattern = re.compile(r'\$\$(.*?)\$\$')

    for match in pattern.finditer(input_string):
        # Text before the math block
        before = input_string[pos:match.start()]
        parts = [s.strip() for s in before.split(';') if s.strip()]
        if parts:
            # Attach to previous segment if contiguous (no semicolon between)
            if result and not before.strip().startswith(';'):
                # merge last piece with this text
                result[-1] += " " + parts[0]
                parts = parts[1:]
            result.extend(parts)
        
        math_block = match.group(0)
        
        # If the math block immediately follows text (no semicolon between),
        # attach it to the previous item
        if result and before and not before.strip().endswith(';'):
            result[-1] += " " + math_block
        else:
            result.append(math_block)
        
        pos = match.end()

    # Remaining text after final math block
    after = input_string[pos:]
    after_parts = [s.strip() for s in after.split(';') if s.strip()]
    result.extend(after_parts)

    return result


def check_hardcoded_paths(text):
    """
    Checks if the transformation query has any hardcoded paths 

    Returns:
        (bool, str | None)
        - True, <message>  if matches found
        - False, None      if no matches
    """
    pattern = re.compile(r'ed_source[^\s]*\.[^\s]*\.[^\s]*', re.IGNORECASE)
    
    matches = []

    for i, line in enumerate(text.splitlines(), start=1):
        if pattern.search(line):
            matches.append(i)

    if not matches:
        return False, None

    if len(matches) == 1:
        message = f"You seem to have hardcoded paths in your Transformation Query on line {matches[0]}"
    else:
        all_but_last = ", ".join(map(str, matches[:-1]))
        message = f"You seem to have hardcoded paths in your Transformation Query on lines {all_but_last} and {matches[-1]}."

    return True, message


def generate_zip(sequence_file_name, sequence, ddl_file_name, ddl, sp_file_name, sp, dataseed_file_name=None, dataseed=None):
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(f"SUNCOR/EDW/Sequences/{sequence_file_name}", sequence)
        zf.writestr(f"SUNCOR/EDW/Tables/{ddl_file_name}", ddl)
        zf.writestr(f"SUNCOR/EDW/Procedures/{sp_file_name}", sp)
        
        if dataseed != None:
            zf.writestr(f"SUNCOR/EDW/Scripts/Dataseed/{dataseed_file_name}", dataseed)
        
    zip_buffer.seek(0)
    return zip_buffer


def generate_download_sttm(file_type):
    if file_type == '.csv':
        csv_buffer = StringIO()
        st.session_state.sttm_df.to_csv(csv_buffer, index=False)
        return csv_buffer.getvalue()
    else:
        excel_buffer = BytesIO()
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            st.session_state.sttm_df.to_excel(writer, index=False, sheet_name=st.session_state.table_name)
        return excel_buffer.getvalue()
    

def normalize_datatype(dtype: str) -> str:
    """
    Simplify Snowflake or SQL-like datatypes into canonical logical forms.
    """
    if pd.isna(dtype):
        return None
    dtype = dtype.strip().upper()
    
    # Handle VARCHAR/TEXT variants
    if dtype.startswith("VARCHAR") or dtype.startswith("STRING") or dtype == "TEXT":
        return "VARCHAR"
    
    # Handle NUMBER/DECIMAL variants
    if dtype.startswith("NUMBER") or dtype.startswith("DECIMAL") or dtype.startswith("NUMERIC") or dtype.startswith("INT"):
        return "NUMBER"
    
    # Handle FLOAT/DOUBLE variants
    if dtype.startswith("FLOAT") or dtype.startswith("DOUBLE") or dtype.startswith("REAL"):
        return "FLOAT"
    
    # Handle BOOLEAN
    if dtype == "BOOLEAN":
        return "BOOLEAN"
    
    # Handle DATE/TIMESTAMP types
    if dtype.startswith("DATE"):
        return "DATE"
    if dtype.startswith("TIMESTAMP"):
        return "TIMESTAMP"
    
    # Fallback — no simplification
    return dtype

# -----------------------
# Save and Load Functions
# -----------------------
def encode_b64(text: str) -> str:
    if text is None or text == 'None':
        return 'None'
    return base64.b64encode(text.encode()).decode()


def decode_b64(text: str) -> str:
    if text is None or text == 'None':
        return None
    return base64.b64decode(text.encode()).decode()


def save_state(save_name, overwrite=False):
    if overwrite:
        overwrite_query = f"DELETE FROM {st.session_state.global_save_table} WHERE SaveName = '{save_name}';"
        st.session_state.snowpark_session.sql(overwrite_query).collect()

    # Retrieve Generated Script Data if they were generated
    if st.session_state.scripts_generated:
        SequenceFileName = st.session_state.sequence_file_name
        SequenceCode = encode_b64(st.session_state.sequence_code)

        DDLFileName = st.session_state.ddl_file_name
        DDLCode = encode_b64(st.session_state.ddl_code)

        if st.session_state.is_dim:
            DataseedFileName = st.session_state.dataseed_file_name
            DataseedCode = encode_b64(st.session_state.dataseed_code)
        else:
            DataseedFileName = 'None'
            DataseedCode = 'None'
        
        SPFileName = st.session_state.sp_file_name
        SPCode = encode_b64(st.session_state.sp_code)
    else:
        SequenceFileName = 'None'
        SequenceCode = 'None'
        DDLFileName = 'None'
        DDLCode = 'None'
        DataseedFileName = 'None'
        DataseedCode = 'None'
        SPFileName = 'None'
        SPCode = 'None'
    
    query = f'''
    INSERT INTO {st.session_state.global_save_table} (SaveName, ProjectDatabase, STTM, FactOrDim, SourceDFDatabases, DimDFDatabases, TransformationQuery, TableDescription, SequenceFileName, SequenceCode, DDLFileName, DDLCode, DataseedFileName, DataseedCode, SPFileName, SPCode)
    VALUES ($${save_name}$$, 
        $${st.session_state.project_database}$$, 
        $${st.session_state.sttm_df.to_json(orient='split')}$$, 
        $${"TRUE" if st.session_state.is_fact else "FALSE"}$$, 
        $${pd.DataFrame(st.session_state.source_df_databases).to_json(orient='split') if st.session_state.source_df_databases is not None else "None"}$$, 
        $${pd.DataFrame(st.session_state.dim_df_databases).to_json(orient='split') if st.session_state.dim_df_databases is not None else "None"}$$, 
        $${st.session_state.transformation_query}$$,
        $${st.session_state.table_description}$$,
        $${SequenceFileName}$$,
        $${SequenceCode}$$,
        $${DDLFileName}$$,
        $${DDLCode}$$,
        $${DataseedFileName}$$,
        $${DataseedCode}$$,
        $${SPFileName}$$,
        $${SPCode}$$
        );'''
    st.session_state.snowpark_session.sql(query).collect()


def load_save_list():
    query = f"SELECT SaveName FROM {st.session_state.global_save_table};"
    result = st.session_state.snowpark_session.sql(query).collect()
    return result


def check_save_exist(save_name):
    query = f"SELECT count(*) FROM {st.session_state.global_save_table} WHERE SaveName = '{save_name}';"
    result = st.session_state.snowpark_session.sql(query).collect()
    if str(result) == "[Row(COUNT(*)=0)]":
        return True
    else:
        return False

def load_state(save_name):
    # Reset necessary session state variables
    st.session_state.source_df = None
    st.session_state.dim_df = None
    st.session_state.scripts_generated = False
    st.session_state.persisted_validation_result = False
    
    st.session_state.sequence_file_name = None
    st.session_state.sequence_code = None
    st.session_state.ddl_file_name = None
    st.session_state.ddl_code = None
    st.session_state.sp_file_name = None
    st.session_state.sp_code = None
    st.session_state.dataseed_file_name = None
    st.session_state.dataseed_code = None

    # Build + Execute Query + Retrieve Result
    query = f"SELECT * FROM {st.session_state.global_save_table} WHERE SaveName = '{save_name}';"
    result = st.session_state.snowpark_session.sql(query).collect()
    save_content = result[0]
    
    # Assign results to session state variables
    st.session_state.project_database = save_content.ProjectDatabase
    st.session_state.sttm_df = pd.read_json(io.StringIO(save_content.STTM), orient='split')
    
    if save_content.FactOrDim:
        st.session_state.is_fact = True
        st.session_state.is_dim = False
    else:
        st.session_state.is_dim = True
        st.session_state.is_fact = False
    
    if save_content.SourceDFDatabases == "None":
        st.session_state.source_df_databases = None
    else:
        st.session_state.source_df_databases = pd.read_json(io.StringIO(save_content.SourceDFDatabases), orient='split')
    
    if save_content.DimDFDatabases == "None":
        st.session_state.dim_df_databases = None
    else:
        st.session_state.dim_df_databases = pd.read_json(io.StringIO(save_content.DimDFDatabases), orient='split')
    
    if save_content.TransformationQuery == "None" or save_content.TransformationQuery == '':
        st.session_state.transformation_query = None
    else:
        st.session_state.transformation_query = save_content.TransformationQuery

    if save_content.TableDescription == "None" or save_content.TableDescription == "":
        st.session_state.table_description = None
    else:
        st.session_state.table_description = save_content.TableDescription 

    if save_content.SequenceFileName != "None" and save_content.DDLFileName != "None" and save_content.SPFileName != "None":
        st.session_state.scripts_generated = True

        st.session_state.sequence_file_name = save_content.SequenceFileName 
        st.session_state.sequence_code = decode_b64(save_content.SequenceCode)

        st.session_state.ddl_file_name = save_content.DDLFileName 
        st.session_state.ddl_code = decode_b64(save_content.DDLCode)

        if st.session_state.is_dim:
            st.session_state.dataseed_file_name = save_content.DataseedFileName
            st.session_state.dataseed_code = decode_b64(save_content.DataseedCode)
        
        st.session_state.sp_file_name = save_content.SPFileName 
        st.session_state.sp_code = decode_b64(save_content.SPCode)

    # Toggle necessary session state variable to process a load
    st.session_state.script_reinitiate = True
    st.session_state.recalculate_project_database_index = True
    st.session_state.notify_successful_load = True
    st.session_state.load_route = True
    st.rerun()


# ----------------------------------------------------------
# Session state variables requiring earlier functions
# ----------------------------------------------------------
if "database_list" not in st.session_state or "ed_source_dev_index" not in st.session_state:
    st.session_state.database_list, st.session_state.ed_source_dev_index = get_database_list()

if "database_list" in st.session_state:
    st.session_state.project_database_list = [db for db in st.session_state.database_list if db.lower().startswith("prj")]

if "database_selected" not in st.session_state:
    st.session_state.database_selected =  st.session_state.database_list[st.session_state.ed_source_dev_index]

if "save_list" not in st.session_state:
    st.session_state.save_list = load_save_list()


# -------------------------------------------------------
# Rerun the app after initializing key session variables
# -------------------------------------------------------
# Fixes a bug where duplicate widgets appear while running the app in snowflake when streamlit triggers a rerun after user interaction
if "rerun_once" not in st.session_state:
    st.session_state.rerun_once = True

if st.session_state.rerun_once:
    st.session_state.rerun_once = False
    st.rerun()


# -----------------------
# Start of UI Elements
# -----------------------
# -------------------------------
# Initialize Project Database
# -------------------------------
st.markdown("<h1 style='text-align: center;'>DIMENSIONAL MODELER</h1>", unsafe_allow_html=True)
with st.expander("SELECT PROJECT AND STATE", icon=":material/folder_code:", expanded=True):
    st.markdown("##### Project Database & App State")
    st.markdown(
    ":red-badge[📌 PRJ_] :blue-badge[⭐ Default Dimension Source] :green-badge[☁️ Default Deployment Location] "
    )
    col1, col2, col3 = st.columns([8,3,3])
    with col1:
        if st.session_state.recalculate_project_database_index:
            try:
                st.session_state.project_database_index = st.session_state.project_database_list.index(st.session_state.project_database)
            except:
                st.session_state.project_database_inde = 0
            st.session_state.recalculate_project_database_index = False

        st.session_state.project_database = st.selectbox(label="Project Database",
                                                        label_visibility="collapsed",
                                                        options=st.session_state.project_database_list,
                                                        index=st.session_state.project_database_index,
                                                        on_change=reload_dim_df)

    with col2:
        load_popover = st.popover('Load State', width='stretch', icon=':material/article_shortcut:')

        with load_popover:
            with st.container(width=440, key='load_popover'):
                st.subheader(':yellow[:material/article_shortcut: LOAD STATE]')
                selected_save = st.selectbox('Save List', st.session_state.save_list, label_visibility='collapsed', placeholder='Select a Saved State', index=None)
                st.caption('Load a previously saved state into Dimensional Modeler!')

                st.session_state.load_bottom_container = st.empty()
                with st.session_state.load_bottom_container.container(horizontal_alignment='left', horizontal=True):
                    trigger_load = st.button('Load', icon=':material/article_shortcut:', width=160)
                    manage_saves_global_load = st.button('Manage Saves', icon=':material/save:', type='tertiary', key="Manage Saves for Load")

            if trigger_load:
                if selected_save is None:
                    with st.session_state.load_bottom_container:
                        st.error("Please select a State to Load!")
                else:
                    try:
                        load_state(selected_save)
                    except Exception as e:
                        display_error(e, 'Load Failed')

            if st.session_state.notify_successful_load:
                st.session_state.load_bottom_container.success(f'Successfully Loaded {selected_save}', icon=':material/done_all:')
                st.toast('State Loaded Successfully!', icon='✅', duration=2)
                st.session_state.notify_successful_load = False
            
            if manage_saves_global_load:
                manage_saves_dialog()

    with col3:
        save_popover = st.popover('Save State', width='stretch', icon=':material/save:')
    st.caption("Your project database is used as Default Dimension Source and as the Default Deployment Database / Repository")


# -------------------------------
# Widget to upload / load STTM
# -------------------------------
with st.expander("INITIALIZE YOUR STTM", icon=":material/data_check:", expanded=True):
    upload_tab, documentation_tab = st.tabs(["UPLOAD STTM", "DOCUMENTATION"])
    
    with upload_tab:
        st.markdown("##### Upload your STTM")
        uploaded_sttm = st.file_uploader(
            "Upload your STTM",
            label_visibility="collapsed",
        )

        if uploaded_sttm is None and st.session_state.load_route:
            # Do nothing, Load State Already reassigned everything, switching to load route
            pass

        elif uploaded_sttm is None and not st.session_state.load_route:
            # File was uploaded, nothing was loaded, and the user crossed out the file
            st.session_state.table_name = None
            st.session_state.table_description = None
            
            st.session_state.sttm_df = None

            st.session_state.source_df = None
            st.session_state.source_df_databases = None
            
            st.session_state.dim_df = None
            st.session_state.dim_df_databases = None

            st.session_state.is_fact = False
            st.session_state.is_dim = False

            st.session_state.transformation_query = None
            st.session_state.scripts_generated = False
            st.session_state.persisted_validation_result = False
        
        elif uploaded_sttm is None and st.session_state.load_route:
            # File was loaded after the something was uploaded
            # and then the user crossed out the uploaded file
            pass
        
        elif st.session_state.uploaded_sttm != uploaded_sttm:
            # A new file was uploaded.
            # If in load_route switch to upload route
            # If in upload route, process new file and discard old file
            st.session_state.table_name = None
            st.session_state.table_description = None
            
            st.session_state.sttm_df = None

            st.session_state.source_df = None
            st.session_state.source_df_databases = None
            
            st.session_state.dim_df = None
            st.session_state.dim_df_databases = None

            st.session_state.is_fact = False
            st.session_state.is_dim = False

            st.session_state.transformation_query = None
            st.session_state.scripts_generated = False
            st.session_state.persisted_validation_result = False

            st.session_state.reupload_notifs = True
            st.session_state.script_reinitiate = True
            
            st.session_state.uploaded_sttm = uploaded_sttm

            st.session_state.examine_uploaded_file = True
            st.session_state.load_route = False

        if st.session_state.examine_uploaded_file:
            st.session_state.examine_uploaded_file = False
            if st.session_state.uploaded_sttm is not None:
                st.session_state.file_uploaded_before = True
                file_extension = st.session_state.uploaded_sttm.name.split('.')[-1].strip()
                if file_extension == "xlsx":
                    st.session_state.sttm_df = pd.read_excel(st.session_state.uploaded_sttm)
                elif file_extension == "csv":
                    st.session_state.sttm_df = pd.read_csv(st.session_state.uploaded_sttm)
                else:
                    st.error("Unsupported File Type! Please upload either a **.csv** or **.xlsx**", icon=":material/web_asset_off:")
                    st.session_state.sttm_df = None
                    st.stop()
                schema_type = validate_sttm_schema()
                if not schema_type:
                    st.error("Invalid Schema Detected! Your uploaded file doesn't follow **EDW - STTM** Schema.", icon=":material/table:")
                    st.session_state.sttm_df = None
                    st.stop()
                if st.session_state.reupload_notifs:
                    st.toast('STTM Successfully Initialized!. Scroll down to Continue', icon='⬇️')
                    st.session_state.reupload_notifs = False
                if st.session_state.is_fact == False and st.session_state.is_dim == False:
                    if schema_type == 'FACT':
                        st.session_state.is_fact = True
                    if schema_type == 'DIM':
                        st.session_state.is_dim = True
        
    with documentation_tab:
        st.warning('This page is still under construction. Please check back later!', icon=':material/construction:')


# -------------------------------
# STTM Initialized Section
# -------------------------------
if st.session_state.sttm_df is not None and not st.session_state.sttm_df.empty:
    st.html("<h3>" "</h3>")
    st.html("<h3>" "</h3>")
    col1, col2 = st.columns([4,1], vertical_alignment="bottom")
    with col1:
        if 'table_title' not in st.session_state:
            st.session_state.table_title = st.empty()
    with col2:
        if 'sttm_download_popover' not in st.session_state:
            st.session_state.sttm_download_popover = st.empty()
    
    # Column Help Messages
    # Don't include dynamic content as that leads to the STTM data editor bugging out!
    project_help = (
        ''
        "| :material/topic: `QRG` | **FOR PROJECT** |\n"
        "|--------------|----------------|\n"
        f"|Column Description | The name of the Project the FACT or DIM is being built for. |\n"
        "|Generation Logic | Used only as **STTM metadata**. Not used in Script Generation. |"
    )

    tableSchemaName_help = (
        "| :material/topic: `QRG` | **FOR TABLESCHEMANAME** |\n"
        "|--------------|----------------|\n"
        f"| Column Description | The Schema this table is going to be deployed under. |\n"
        "| Generation Logic | Used as the deployment schema of the generated objects. |"
    )

    table_help = (
        "| :material/topic: `QRG` | **FOR TABLE** |\n"
        "|--------------|----------------|\n"
        f"| Column Description | The name of the FACT or DIM table you are building. |\n"
        f"| Input Instructions |  Should be the same value in all rows! |\n"
        "| Generation Logic | The scripts are generated in order to build a table with this name. |"
    )

    schema_help = (
        "| :material/topic: `QRG` | **FOR SCHEMA** |\n"
        "|--------------|----------------|\n"
        f"| Column Description | The Schema of the Source tables you are pulling data from. |\n"
        f"| For your Information |  The columns -  Schema, ViewName, and Alias are linked, with each trio representing one unique source. |\n"
        f"| Input Instructions | The number of rows should match the number of unique sources. |\n"
        "| Generation Logic | Used to populate data from Source Tables in the Stored Procedure. |"
    )
    
    st.session_state.sttm_df = st.session_state.sttm_df.fillna('')
    st.session_state.sttm_df = st.session_state.sttm_df.astype(str)

    st.session_state.sttm_df = dynamic_input_data_editor(
        st.session_state.sttm_df.reset_index(drop=True), 
        key='sttm_data_editor',
        on_change=sttm_changed_reload,
        num_rows='dynamic',
        hide_index=True,
        column_config= {
            'Project': st.column_config.TextColumn(
                label='Project',
                help=project_help,
                default=''),
            'TableSchemaName': st.column_config.TextColumn(
                label='TableSchemaName',
                help=tableSchemaName_help,
                default=''),
            'Table': st.column_config.TextColumn(
                label='Table',
                help=table_help,
                default=''),
            'Schema': st.column_config.TextColumn(
                label='Schema',
                default=''),
            'ViewName': st.column_config.TextColumn(
                label='ViewName',
                default=''),
            'Alias': st.column_config.TextColumn(
                label='Alias',
                default=''),
            'Column_Name': st.column_config.TextColumn(
                label='Column_Name',
                default=''),
            'Description': st.column_config.TextColumn(
                label='Description',
                default=''),
            'Target_Data_Type': st.column_config.TextColumn(
                label='Target_Data_Type',
                default=''),
            'Business_Key': st.column_config.TextColumn(
                label='Business_Key',
                default=''),
            'Type1Col': st.column_config.TextColumn(
                label='Type1Col',
                default=''),
            'Mandatory': st.column_config.TextColumn(
                label='Mandatory',
                default=''),
            'Data_Read_Type': st.column_config.TextColumn(
                label='Data_Read_Type',
                default=''),
            'SourceDatetimeColumn': st.column_config.TextColumn(
                label='SourceDatetimeColumn',
                default=''),
            'Table Description': st.column_config.TextColumn(
                label='Table Description',
                default=''),
            'Source_Create_Datetime_Column': st.column_config.TextColumn(
                label='Source_Create_Datetime_Column',
                default=''),
            'Source_Update_Datetime_Column': st.column_config.TextColumn(
                label='Source_Update_Datetime_Column',
                default=''),
            'Creation Date': st.column_config.TextColumn(
                label='Creation Date',
                default=''),
            'Modified Date': st.column_config.TextColumn(
                label='Modified Date',
                default=''),
            'Last Updated By': st.column_config.TextColumn(
                label='Last Updated By',
                default=''),
            'Last Updated by': st.column_config.TextColumn(
                label='Last Updated by',
                default=''),
            'Stage_Column_Name': st.column_config.TextColumn(
                label='Stage_Column_Name',
                default=''),
            'ParentTableName': st.column_config.TextColumn(
                label='ParentTableName',
                default=''),
            'ParentColumnName': st.column_config.TextColumn(
                label='ParentColumnName',
                default=''),
            'ParentTableSID': st.column_config.TextColumn(
                label='ParentTableSID',
                default=''),
        }
    )
    
    st.session_state.sttm_df = st.session_state.sttm_df.replace('', None)
    st.session_state.sttm_df = st.session_state.sttm_df.map(lambda x: x.strip() if isinstance(x, str) else x)
    
    # Used for dynamic table name in STTM Data Editor Section
    if st.session_state.sttm_df is not None:
        st.session_state.table_name = st.session_state.sttm_df["Table"].iat[0]

    # STTM needs to be initialized before we can set the title
    with st.session_state.table_title:
        st.subheader(f":{'green' if st.session_state.is_fact else 'blue'}[{st.session_state.table_name.upper()}]")
    
    # STTM needs to be initialized before the save_name can be set 
    with st.session_state.sttm_download_popover.popover('DOWNLOAD', width='stretch', icon=":material/download:"):
        with st.container(width=350):
            st.subheader(':blue[:material/dataset: Download STTM]')
            col1, col2 = st.columns([5,2])
            with col1:
                sttm_name = st.text_input(
                    'Name your STTM',
                    icon=':material/menu:',
                    label_visibility='collapsed', 
                    value=st.session_state.table_name,
                    disabled=True,
                )
            with col2:
                file_type = st.selectbox('file_type', ['.csv', '.xlsx'], label_visibility='collapsed')
            st.caption('Download the current **STTM** in your desired format!')
            st.download_button(
                label="Download STTM",
                file_name=f"{sttm_name}{file_type}",
                data=generate_download_sttm(file_type),
                mime="text/csv" if file_type == '.csv' else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                icon=":material/download:",
                on_click='ignore'
                )

    

    # ---------------------------------------------
    # Sources and Dimensions for subsequent reruns
    # ---------------------------------------------
    if not st.session_state.script_reinitiate:
        # -------------------------------
        # Generate source_df
        # -------------------------------
        with st.expander("Selected Sources", icon=":material/database:"):
            st.session_state.sources_validator_status = st.empty()
            
            if st.session_state.source_df is None:
                # Generate source_df from sttm_df
                st.session_state.source_df = st.session_state.sttm_df[['Schema', 'ViewName', 'Alias']]
                st.session_state.source_df = st.session_state.source_df.dropna(subset=['Schema', 'ViewName'], how='any')
                st.session_state.source_df = st.session_state.source_df.drop_duplicates(subset=['Schema', 'ViewName'])

                if st.session_state.source_df_databases is not None:
                    st.session_state.source_df["Database"] = st.session_state.source_df_databases
                    st.session_state.source_df["Database"] = st.session_state.source_df["Database"].fillna(st.session_state.database_selected)
                elif st.session_state.database_selected is not None:
                    st.session_state.source_df["Database"] = st.session_state.database_selected
                    st.session_state.source_df_databases = st.session_state.source_df['Database']
                else:
                    st.session_state.source_df["Database"] = "ED_SOURCE_DEV"

                st.session_state.source_df = st.session_state.source_df[['Database', 'Schema', 'ViewName', 'Alias']]
                st.session_state.source_df = st.session_state.source_df.dropna(axis=1, how='all')

                if list(st.session_state.source_df.columns) == ['Database']:
                    st.session_state.source_df = pd.DataFrame()
                
                if not st.session_state.source_df.empty:
                    st.session_state.source_df['Validation'] = validate_all_sources_for_subsequent_reruns(st.session_state.source_df)
    

            if not st.session_state.source_df.empty:
                st.selectbox(
                    "Bulk Change Database",
                    st.session_state.database_list,
                    index=st.session_state.ed_source_dev_index,
                    key="database_selected",
                    on_change=full_reload_source_df)
                
                st.caption("Please Update the STTM above if you would like to change the Schema, ViewName or Alias!")

                st.session_state.source_df = st.data_editor(
                    st.session_state.source_df,
                    hide_index=True,
                    on_change=intiate_source_df_db_col_update,
                    column_config={
                        "Database": st.column_config.SelectboxColumn(
                            options=st.session_state.database_list,
                            required=True
                        ),
                        "Schema": st.column_config.Column(disabled=True),
                        "ViewName": st.column_config.Column(disabled=True),
                        "Alias": st.column_config.Column(disabled=True),
                        "Validation": st.column_config.Column(disabled=True),
                    })
            else:
                st.markdown("##### Sources")
                st.caption("Please Update the STTM above if you would like to change the Schema, ViewName or Alias!")
                st.error('No sources are defined in your STTM!', icon=':material/file_copy_off:')

        
            # Triggers a script reload. The following logic needs to be inside an if block
            # because source_df only updates to a changed df with updated databases at this point in code
            if st.session_state.update_source_df:
                st.session_state.source_df_databases = st.session_state.source_df['Database']
                st.session_state.source_df = None
                st.session_state.update_source_df = False
                st.rerun()


        # -------------------------------
        # Joined Dimensions Widget
        # -------------------------------
        if st.session_state.is_fact:
            with st.expander("Joined Dimensions", icon=":material/star:"):
                st.session_state.dimension_validator_status = st.empty()

                # -------------------------------
                # Generate dim_df
                # -------------------------------
                if st.session_state.dim_df is None:
                    # Generate dim_df from sttm_df
                    st.session_state.dim_df = st.session_state.sttm_df[['ParentTableName', 'ParentColumnName', 'ParentTableSID']]
                    st.session_state.dim_df = st.session_state.dim_df.dropna()
                    st.session_state.dim_df = st.session_state.dim_df.drop_duplicates()

                    if st.session_state.dim_df_databases is not None:
                        st.session_state.dim_df["Database"] = st.session_state.dim_df_databases
                        st.session_state.dim_df["Database"] = st.session_state.dim_df["Database"].fillna(st.session_state.project_database)
                    else:
                        st.session_state.dim_df["Database"] = st.session_state.project_database
                        st.session_state.dim_df_databases = st.session_state.dim_df['Database']

                    st.session_state.dim_df = st.session_state.dim_df[['Database', 'ParentTableName', 'ParentColumnName', 'ParentTableSID']]
                    st.session_state.dim_df = st.session_state.dim_df.dropna(axis=1, how='all')

                    if list(st.session_state.dim_df.columns) == ['Database']:
                        st.session_state.dim_df = pd.DataFrame()
                    
                    if not st.session_state.dim_df.empty:
                        st.session_state.dim_df['Validation'] = validate_all_dims_for_subsequent_reruns(st.session_state.dim_df)

                st.markdown("##### Dimensions")
                st.caption("Please Update the STTM above if you would like to change the ParentTableName, ParentColumnName or ParentTableSID!")
                if not st.session_state.dim_df.empty:
                    st.session_state.dim_df = st.data_editor(
                        st.session_state.dim_df,
                        hide_index=True,
                        on_change=intiate_dim_df_db_col_update,
                        column_config={
                            "Database": st.column_config.SelectboxColumn(
                                options=st.session_state.database_list,
                                required=True
                            ),
                            "ParentTableName": st.column_config.Column(disabled=True),
                            "ParentColumnName": st.column_config.Column(disabled=True),
                            "ParentTableSID": st.column_config.Column(disabled=True),
                            "Validation": st.column_config.Column(disabled=True),
                        })
                else:
                    st.error('No dimensions are defined in your STTM!', icon=':material/file_copy_off:')
                
                # Triggers a script reload. The following logic needs to be inside an if block
                # because dim_df only updates to a changed df with updated databases at this point in code
                if st.session_state.update_dim_df:
                    st.session_state.dim_df_databases = st.session_state.dim_df['Database']
                    st.session_state.dim_df = None
                    st.session_state.update_dim_df = False
                    st.rerun()


    # -------------------------------
    # Sources Validator Placeholders
    # -------------------------------
    if st.session_state.script_reinitiate:
        selected_sources_widget = st.empty()
        
        if st.session_state.is_fact:
            joined_dimension_widget = st.empty()

    # ---------------------------------
    # Show Transformation Query Widget
    # ---------------------------------
    st.html("<h3>" "</h3>")
    st.html("<h3>" "</h3>")
    with st.expander("TRANSFORMATION QUERY", icon=":material/data_object:", expanded=True):
        
        # Define Transformation Query Widget Tabs
        with st.container(key="transformation_query_container"):
            st.html("""
                <style>
                    /* Hide the tab underline element only inside the transformation_query_container */
                    div.st-key-transformation_query_container div[data-baseweb="tab-border"] {
                        display: none !important;
                    }
                    div.st-key-transformation_query_container div[data-baseweb="tab-list"] {
                        justify-content: center !important;
                    }
                    div.st-key-transformation_query_container button[data-baseweb="tab"] {
                        width: 50% !important;
                    }
                </style>
            """)
            enter_query_tab, ai_chat, documentation_tab = st.tabs(["QUERY CODE EDITOR", "✨ AI CHATBOT", "DOCUMENTATION"])
            
            with enter_query_tab:
                info_bar_css = '''
                background-color: #bee1e5;

                body > #root .ace-streamlit-dark~& {
                    background-color: #30333d;
                }

                .ace-streamlit-dark~& span {
                    color: #fff;
                    opacity: 0.6;
                }

                span {
                    color: #000;
                    opacity: 0.5;
                }

                .code_editor-info.message {
                    width: inherit;
                    margin-right: 200px;
                    order: 2;
                    text-align: center;
                    opacity: 0;
                    transition: opacity 0.5s ease-in-out;
                    color: #87c1ed;
                }

                .ace-streamlit-dark~& .code_editor-info.message.show {
                    opacity: 0.8;
                }
                '''

                # create info bar dictionary
                transformation_query_info_bar = {
                "name": "language info",
                "css": info_bar_css,
                "style": {
                            "order": "1",
                            "display": "flex",
                            "flexDirection": "row",
                            "alignItems": "center",
                            "width": "100%",
                            "height": "2.5rem",
                            "padding": "0rem 0.75rem",
                            "borderRadius": "8px 8px 0px 0px",
                            "zIndex": "9993"
                        },
                "info": [
                            {
                                "name": "Transformation Query",
                                "style": {"width": "300px", "fontWeight": 400}
                            }
                        ]
                }

                transformation_query_custom_btns = [
                    {
                        "name": "Validate",
                        "feather": "CheckSquare",
                        "hasText": True,
                        "alwaysOn": True,
                        "primary": True,
                        "commands": ["submit"],
                        "style": {"right": "0.4rem", "top": "0.1rem"}
                    },
                    {
                        "name": "Copy",
                        "feather": "Copy",
                        "hasText": True,
                        "alwaysOn": True,
                        "primary": True,
                        "commands": [
                                        "copyAll",
                                        [
                                            "infoMessage", 
                                            {
                                                "text":"Copied to Clipboard!",
                                                "timeout": 1000, 
                                                "classToggle": "show"
                                            }
                                        ]   
                                    ],
                        "style": {"right": "6.5rem", "top": "0.05rem"}
                    },
                    {
                        "name": "CommentFix",
                        "commands": ["togglecomment"],
                        "style": {"display": "none"},
                        "bindKey": {"win": "Ctrl-/", "mac": "Command-/"}
                    }
                ]

                # Code Editor Component
                st.session_state.transformation_code_editor_dict = code_editor(
                    st.session_state.transformation_query if st.session_state.transformation_query is not None else '',
                    lang='sql', 
                    height=[10, 20], 
                    response_mode="blur", 
                    key="transformation_query_code_editor", 
                    allow_reset=True,
                    info=transformation_query_info_bar,
                    buttons=transformation_query_custom_btns,
                    options={
                        "wrap": True, 
                        "showLineNumbers": True, 
                        "cursorStyle": "smooth"
                    },
                )
                
                # Transformation query session state updates based on code editor id
                if st.session_state.transformation_code_editor_dict.get('id') != '' and st.session_state.transformation_code_editor_dict.get('id') is not None:
                    if st.session_state.transformation_code_editor_dict.get('id') != st.session_state.transformation_query_code_editor_id:
                        st.session_state.transformation_query = st.session_state.transformation_code_editor_dict.get('text')
                        st.session_state.transformation_query_code_editor_id = st.session_state.transformation_code_editor_dict.get('id')
                        if st.session_state.transformation_code_editor_dict.get('type') == 'submit':
                            st.session_state.validate_query = True
                        st.rerun()

                # Check Transformation Query -> Generate Queries -> Execute the Query
                if st.session_state.validate_query:
                    st.session_state.validate_query = False
                    if st.session_state.transformation_query is None:
                        transformation_query = ""
                    else:
                        transformation_query = st.session_state.transformation_query.strip()
                    if transformation_query == "":
                        with st.empty():
                            st.error("Your Transformation Query is empty! :(", icon=":material/wallet:")
                            time.sleep(2.5)
                            st.empty()
                    else:
                        if "limit" not in transformation_query.lower():
                            if transformation_query.endswith(';'):
                                transformation_query = transformation_query[:-1]
                            transformation_query += " LIMIT 1"
                        
                        # Generate Queries to create Temporary views with Aliases
                        transformation_queries = []
                        for row in st.session_state.source_df.itertuples(index=False):
                            if len(row) == 5:
                                database, schema, viewName, alias, validation = row
                            elif len(row) == 4:
                                database, schema, viewName, validation = row
                                alias = viewName
                            else:
                                st.error('Failed to Validate: Received unexpected number of values when defining sources.', icon=':material/emergency_home:')
                                st.stop()
                            current_temp_view = f"CREATE OR REPLACE VIEW {alias} AS\nSELECT *\nFROM {database}.{schema}.{viewName};"
                            transformation_queries.append(current_temp_view)
                        
                        # Append main transformation query to the list of transformation queries
                        transformation_queries.append(transformation_query)

                        # Execute the Query
                        try:
                            st.session_state.validating_query = st.empty()
                            st.session_state.extra_columns_in_result = None
                            st.session_state.extra_columns_in_sttm = None
                            
                            # Variables defined here to make sure "variable is not defined error" is not encountered 
                            # in the except block incase of an early exception
                            creating_temp_views = False
                            retrieving_data_type = False

                            with st.session_state.validating_query.status("Validating Query...."):
                                # Execute Queries to create Temp Views
                                creating_temp_views = True
                                for query in transformation_queries[:-1]:
                                    st.session_state.snowpark_session.sql(query).collect()
                                creating_temp_views = False
                                
                                # Execute Transformation Query
                                st.session_state.validation_result = st.session_state.snowpark_session.sql(transformation_queries[-1]).collect()

                                # Retrieve Staging Table DataType
                                retrieving_data_type = True
                                st.session_state.temporary_table_name = f'table_{datetime.now().strftime("%Y%m%d_%H%M%S_%f")}'
                                st.session_state.snowpark_session.sql(f'CREATE OR REPLACE TEMPORARY TABLE {st.session_state.temporary_table_name} AS\n{transformation_queries[-1]}').collect()
                                staging_table_describe_df = st.session_state.snowpark_session.sql(f'DESCRIBE TABLE {st.session_state.temporary_table_name}').to_pandas()[['"name"', '"type"']]
                                retrieving_data_type = False
                                
                                # Retrieve Necessary Information from the STTM DF for datatype check
                                sttm_join_col = "Stage_Column_Name" if st.session_state.is_fact else "Column_Name"
                                sttm_df = st.session_state.sttm_df[
                                    (st.session_state.sttm_df['Business_Key'] != 'Y')
                                ][[sttm_join_col, 'Target_Data_Type']]

                                # Inner Join custom sttm df to describe query result df  
                                datatype_mismatch_df = (
                                    sttm_df.assign(Column=sttm_df[sttm_join_col].str.upper())
                                    .merge(
                                        staging_table_describe_df.assign(Column=staging_table_describe_df['"name"'].str.upper()),
                                        on='Column',
                                        how='inner'
                                    )[["Column", '"type"', "Target_Data_Type"]]
                                )

                                # Normalize DataType columns
                                datatype_mismatch_df["normalized_query_datatype"] = datatype_mismatch_df['"type"'].apply(normalize_datatype)
                                datatype_mismatch_df["normalized_sttm_datatype"] = datatype_mismatch_df["Target_Data_Type"].apply(normalize_datatype)
                                
                                # Filter rows where normalized DataTypes differ
                                st.session_state.datatype_mismatch_df = (
                                    datatype_mismatch_df[datatype_mismatch_df["normalized_query_datatype"] != datatype_mismatch_df["normalized_sttm_datatype"]]
                                    [["Column", '"type"', "Target_Data_Type"]]
                                    .rename(columns={
                                        '"type"': "Transformation Query",
                                        "Target_Data_Type": "STTM"
                                    })
                                )
                            
                                # Validating Transformation Query Dataframe to STTM Stage_Column Name
                                st.session_state.result_df_columns = list(st.session_state.validation_result[0].asDict().keys())
                                if st.session_state.is_fact:
                                    st.session_state.sttm_stage_column_names = st.session_state.sttm_df.loc[st.session_state.sttm_df["Target_Data_Type"] != "PK", "Stage_Column_Name"].tolist()
                                else:
                                    st.session_state.sttm_stage_column_names = st.session_state.sttm_df.loc[st.session_state.sttm_df["Target_Data_Type"] != "PK", "Column_Name"].tolist()

                                st.session_state.result_df_counter = Counter(x.lower() for x in st.session_state.result_df_columns)
                                st.session_state.sttm_df_counter = Counter(x.lower() for x in st.session_state.sttm_stage_column_names)

                                # Safely handle None or non-string values
                                # st.session_state.result_df_counter = Counter(
                                #     x.lower() for x in (st.session_state.result_df_columns or []) if isinstance(x, str)
                                # )

                                # st.session_state.sttm_df_counter = Counter(
                                #     x.lower() for x in (st.session_state.sttm_stage_column_names or []) if isinstance(x, str)
                                # )

                                st.session_state.is_subset = all(
                                    st.session_state.sttm_df_counter[k] <= st.session_state.result_df_counter[k]
                                    for k in st.session_state.sttm_df_counter
                                )

                                st.session_state.persisted_validation_result = True
                        
                        except Exception as e:
                            with st.session_state.validating_query:
                                tb_str = traceback.format_exc()
                                if creating_temp_views:
                                    display_error(e, 'Source Validation Failed')
                                elif retrieving_data_type:
                                    display_error(e, 'Datatype Retrieval Failed')
                                else:
                                    display_error(tb_str, 'Invalid Query')
                                    
                                st.session_state.persisted_validation_result = False

                if st.session_state.persisted_validation_result:
                    with st.session_state.validating_query.container():
                        st.session_state.hardcoded_path_presence, st.session_state.hardcoded_warning = check_hardcoded_paths(st.session_state.transformation_query)

                        # Hardcoded Path Warning
                        if st.session_state.hardcoded_path_presence:
                            st.warning(f"Warning: {st.session_state.hardcoded_warning}!", icon=':material/emergency_home:')
                        
                        # Missing Staging Columns Warning
                        if st.session_state.is_subset and len(st.session_state.result_df_columns) == len(st.session_state.sttm_stage_column_names) and st.session_state.datatype_mismatch_df.empty:
                            st.success("Transformation Query is Valid!", icon=":material/check_box:")
                        elif st.session_state.is_subset and len(st.session_state.result_df_columns) == len(st.session_state.sttm_stage_column_names):
                            pass
                        elif st.session_state.is_subset:
                            st.warning(f"Warning: Some columns in your Transformation Query are missing from the STTM's **{'Stage_Column_Name' if st.session_state.is_fact else 'Column_Name'}** and will be ignored unless you update the STTM.", icon=':material/emergency_home:')
                        else:
                            st.warning(f"Warning: The columns returned by your Transformation Query do not match the entries defined in your STTM's **{'Stage_Column_Name' if st.session_state.is_fact else 'Column_Name'}**.", icon=':material/emergency_home:')
                            
                        if st.session_state.extra_columns_in_result is None:                            
                            # Find columns that appear more times in result than in STTM
                            st.session_state.extra_columns_in_result = []
                            for col, count in st.session_state.result_df_counter.items():
                                diff = count - st.session_state.sttm_df_counter.get(col, 0)
                                if diff > 0:
                                    st.session_state.extra_columns_in_result.extend([col] * diff)

                        if st.session_state.extra_columns_in_sttm is None:  
                            # Find columns that appear more times in STTM than in result
                            st.session_state.extra_columns_in_sttm = []
                            for col, count in st.session_state.sttm_df_counter.items():
                                diff = count - st.session_state.result_df_counter.get(col, 0)
                                if diff > 0:
                                    st.session_state.extra_columns_in_sttm.extend([col] * diff)

                        if not st.session_state.datatype_mismatch_df.empty:
                            st.error("**Invalid Query:** There are Datatype Mismatches between your Transformation Query and STTM. Please update your STTM to the correct Datatype!", icon=':material/emergency_home:')
                        
                        # Show Returned Dataframe
                        col1, col2, col3 = st.columns([0.15,0.4,10], vertical_alignment='center', gap=None)
                        with col1:
                            st.container(width='stretch')
                        with col2:
                            st.write('└──')
                        with col3:
                            with st.expander('Returned DataFrame'):
                                data_dicts = [r.asDict() for r in st.session_state.validation_result]
                                query_result_df = pd.DataFrame(data_dicts)
                                st.markdown(":blue-badge[ℹ️ **NOTE: DATA IS LIMITED TO ONLY ONE ROW TO SPEED UP QUERIES!**]")
                                st.dataframe(query_result_df, hide_index=True)

                                if (st.session_state.extra_columns_in_result is not None and len(st.session_state.extra_columns_in_result) > 0) or (st.session_state.extra_columns_in_sttm is not None and len(st.session_state.extra_columns_in_sttm) > 0):
                                    st.markdown(f":yellow-badge[🟡 **PROBLEMATIC COLUMNS**]")
                                    if st.session_state.extra_columns_in_sttm is not None and len(st.session_state.extra_columns_in_sttm) > 0:
                                        st.markdown(f"`PROBLEMATIC COLUMNS IN YOUR STTM {'Stage_Column_Name' if st.session_state.is_fact else 'Column_Name'}`")
                                        st.dataframe(pd.DataFrame([st.session_state.extra_columns_in_sttm]), hide_index=True)
                                    if st.session_state.extra_columns_in_result is not None and len(st.session_state.extra_columns_in_result) > 0:
                                        st.markdown("`PROBLEMATIC COLUMNS IN YOUR TRANSFORMATION QUERY STAGING TABLE`")
                                        st.dataframe(pd.DataFrame([st.session_state.extra_columns_in_result]), hide_index=True)

                                if not st.session_state.datatype_mismatch_df.empty:
                                    st.markdown(f":red-badge[🔴 **DATATYPE MISMATCHES**]")
                                    st.dataframe(st.session_state.datatype_mismatch_df, hide_index=True)

            with ai_chat:
                st.warning('This page is still under construction. Please check back later!', icon=':material/construction:')
            
            with documentation_tab:
                st.warning('This page is still under construction. Please check back later!', icon=':material/construction:')
    
    # ---------------------------------------------
    # Sources and Dimensions for Initial load
    # ---------------------------------------------
    if st.session_state.script_reinitiate:
        with selected_sources_widget:
            # -------------------------------
            # Generate source_df
            # -------------------------------
            if st.session_state.source_df is None:
                # Generate source_df from sttm_df
                st.session_state.source_df = st.session_state.sttm_df[['Schema', 'ViewName', 'Alias']]
                st.session_state.source_df = st.session_state.source_df.dropna(subset=['Schema', 'ViewName'], how='any')
                st.session_state.source_df = st.session_state.source_df.drop_duplicates(subset=['Schema', 'ViewName'])

                if st.session_state.source_df_databases is not None:
                    st.session_state.source_df["Database"] = st.session_state.source_df_databases
                    st.session_state.source_df["Database"] = st.session_state.source_df["Database"].fillna(st.session_state.database_selected)
                elif st.session_state.database_selected is not None:
                    st.session_state.source_df["Database"] = st.session_state.database_selected
                    st.session_state.source_df_databases = st.session_state.source_df['Database']
                else:
                    st.session_state.source_df["Database"] = "ED_SOURCE_DEV"

                st.session_state.source_df = st.session_state.source_df[['Database', 'Schema', 'ViewName', 'Alias']]
                st.session_state.source_df = st.session_state.source_df.dropna(axis=1, how='all')

                if list(st.session_state.source_df.columns) == ['Database']:
                    st.session_state.source_df = pd.DataFrame()
                
                if not st.session_state.source_df.empty:
                    st.session_state.source_df['Validation'] = validate_all_sources(st.session_state.source_df)
        
        with selected_sources_widget:
            with st.expander("Selected Sources", icon=":material/database:"):
                
                if not st.session_state.source_df.empty:
                    st.selectbox(
                        "Bulk Change Database",
                        st.session_state.database_list,
                        index=st.session_state.ed_source_dev_index,
                        key="database_selected",
                        on_change=full_reload_source_df)
                    
                    st.caption("Please Update the STTM above if you would like to change the Schema, ViewName or Alias!")

                    st.session_state.source_df = st.data_editor(
                        st.session_state.source_df,
                        hide_index=True,
                        on_change=intiate_source_df_db_col_update,
                        column_config={
                            "Database": st.column_config.SelectboxColumn(
                                options=st.session_state.database_list,
                                required=True
                            ),
                            "Schema": st.column_config.Column(disabled=True),
                            "ViewName": st.column_config.Column(disabled=True),
                            "Alias": st.column_config.Column(disabled=True),
                            "Validation": st.column_config.Column(disabled=True),
                        })
                else:
                    st.markdown("##### Sources")
                    st.caption("Please Update the STTM above if you would like to change the Schema, ViewName or Alias!")
                    st.error('No sources are defined in your STTM!', icon=':material/file_copy_off:')

            
                # Triggers a script reload. The following logic needs to be inside an if block
                # because source_df only updates to a changed df with updated databases at this point in code
                if st.session_state.update_source_df:
                    st.session_state.source_df_databases = st.session_state.source_df['Database']
                    st.session_state.source_df = None
                    st.session_state.update_source_df = False
                    st.rerun()


        # -------------------------------
        # Joined Dimensions Widget
        # -------------------------------
        if st.session_state.is_fact:
            with joined_dimension_widget:
                # -------------------------------
                # Generate dim_df
                # -------------------------------
                if st.session_state.dim_df is None:
                    # Generate dim_df from sttm_df
                    st.session_state.dim_df = st.session_state.sttm_df[['ParentTableName', 'ParentColumnName', 'ParentTableSID']]
                    st.session_state.dim_df = st.session_state.dim_df.dropna()
                    st.session_state.dim_df = st.session_state.dim_df.drop_duplicates()

                    if st.session_state.dim_df_databases is not None:
                        st.session_state.dim_df["Database"] = st.session_state.dim_df_databases
                        st.session_state.dim_df["Database"] = st.session_state.dim_df["Database"].fillna(st.session_state.project_database)
                    else:
                        st.session_state.dim_df["Database"] = st.session_state.project_database
                        st.session_state.dim_df_databases = st.session_state.dim_df['Database']

                    st.session_state.dim_df = st.session_state.dim_df[['Database', 'ParentTableName', 'ParentColumnName', 'ParentTableSID']]
                    st.session_state.dim_df = st.session_state.dim_df.dropna(axis=1, how='all')

                    if list(st.session_state.dim_df.columns) == ['Database']:
                        st.session_state.dim_df = pd.DataFrame()
                    
                    if not st.session_state.dim_df.empty:
                        st.session_state.dim_df['Validation'] = validate_all_dims(st.session_state.dim_df)

            with joined_dimension_widget:
                with st.expander("Joined Dimensions", icon=":material/star:"):

                    st.markdown("##### Dimensions")
                    st.caption("Please Update the STTM above if you would like to change the ParentTableName, ParentColumnName or ParentTableSID!")
                    if not st.session_state.dim_df.empty:
                        st.session_state.dim_df = st.data_editor(
                            st.session_state.dim_df,
                            hide_index=True,
                            on_change=intiate_dim_df_db_col_update,
                            column_config={
                                "Database": st.column_config.SelectboxColumn(
                                    options=st.session_state.database_list,
                                    required=True
                                ),
                                "ParentTableName": st.column_config.Column(disabled=True),
                                "ParentColumnName": st.column_config.Column(disabled=True),
                                "ParentTableSID": st.column_config.Column(disabled=True),
                                "Validation": st.column_config.Column(disabled=True),
                            })
                    else:
                        st.error('No dimensions are defined in your STTM!', icon=':material/file_copy_off:')
                    
                    # Triggers a script reload. The following logic needs to be inside an if block
                    # because dim_df only updates to a changed df with updated databases at this point in code
                    if st.session_state.update_dim_df:
                        st.session_state.dim_df_databases = st.session_state.dim_df['Database']
                        st.session_state.dim_df = None
                        st.session_state.update_dim_df = False
                        st.rerun()
    
    st.session_state.script_reinitiate = False

    # ---------------------------------
    # Show Generate Script Widget
    # ---------------------------------
    st.html("<h3>" "</h3>")
    st.html("<h3>" "</h3>")
    with st.container(border=True):
        st.subheader(f":material/deployed_code: Generate :{'green' if st.session_state.is_fact else 'blue'}[{st.session_state.table_name.upper()}]")
        st.caption('Click the Generate Button once you are ready and the **DIMENSIONAL MODELER** will generate all Snowflake scripts!')
        tab1, tab2 = st.tabs(['Table Description', 'Checklist'])
        with tab1:
            st.session_state.table_description = st.text_input('Table Description', placeholder=f'Description for table {st.session_state.table_name.upper()}', value=st.session_state.table_description)
        with tab2:
            st.checkbox('All Sources Validated', disabled=True, value=True)
            st.checkbox('All Dimensions Validated', disabled=True, value=True)
            st.checkbox('Transformation Query Present', disabled=True, value=True)
        st.button('Generate!', on_click=trigger_script_generation)
    

    # ---------------------------------
    # Script Generation
    # ---------------------------------
    if st.session_state.generate_script or st.session_state.regenerate_scripts:
        st.session_state.generate_script = False
        if st.session_state.scripts_generated:
            st.session_state.retrigger_script_generation = True
        else:
            try:
                if st.session_state.is_fact:
                    sequence, ddl, sp = generate_fact_scripts(
                        st.session_state.sttm_df,
                        st.session_state.table_description.strip() if st.session_state.table_description is not None else '',
                        re.sub(r"'", "''", st.session_state.transformation_query.rstrip(';') if st.session_state.transformation_query is not None else '')
                    )
                
                if st.session_state.is_dim:
                    sequence, ddl, dataseed, sp = generate_dim_scripts(
                        st.session_state.sttm_df, 
                        st.session_state.table_description.strip() if st.session_state.table_description is not None else '',
                        re.sub(r"'", "''", st.session_state.transformation_query.rstrip(';') if st.session_state.transformation_query is not None else '')
                    )
                    st.session_state.dataseed_file_name, st.session_state.dataseed_code = dataseed

                st.session_state.sequence_file_name, st.session_state.sequence_code = sequence
                st.session_state.ddl_file_name, st.session_state.ddl_code = ddl
                st.session_state.sp_file_name, st.session_state.sp_code = sp       
                st.session_state.scripts_generated = True
                st.session_state.regenerate_scripts = False
                st.toast('Scripts Generated!', icon='✨', duration=3)
            except Exception as e:
                display_error(e, 'Failed to Generate Scripts')


    
    # ---------------------------------
    # Generated Fact Script Widgets
    # ---------------------------------
    if st.session_state.scripts_generated and not st.session_state.retrigger_script_generation:
        st.subheader(f"`{st.session_state.project_database}` / `EDW` ")
        
        code_editor_custom_btns = [
            {
                "name": "Copy",
                "feather": "Copy",
                "alwaysOn": True,
                "commands": ["copyAll"],
                "primary": True,
                "style": {"top": "0.5rem", "right": "0.9rem"}
            },
            {
                "name": "CommentFix",
                "commands": ["togglecomment"],
                "style": {"display": "none"},
                "bindKey": {"win": "Ctrl-/", "mac": "Command-/"}
            }
        ]
        # ---------------------------------
        # Sequence File
        # ---------------------------------
        col1, col2, col3 = st.columns([0.8,0.8,16], vertical_alignment='center', gap=None)
        with col1:
            st.container(width='stretch')
        with col2:
            st.write('├──')
        with col3:
            with st.expander(st.session_state.sequence_file_name):
                sequence_code_editor_dict = code_editor(
                    st.session_state.sequence_code, 
                    lang='sql', 
                    height=[4, 4], 
                    response_mode="blur", 
                    key="sequence_code_editor", 
                    allow_reset=True,
                    buttons=code_editor_custom_btns,
                    options={
                        "wrap": True, 
                        "showLineNumbers": True, 
                        "cursorStyle": "smooth"},
                )

                if sequence_code_editor_dict.get('id') != '' and sequence_code_editor_dict.get('id') is not None:
                    if sequence_code_editor_dict.get('id') != st.session_state.sequence_code_editor_id:
                        st.session_state.sequence_code = sequence_code_editor_dict.get('text')
                        st.session_state.sequence_code_editor_id = sequence_code_editor_dict.get('id')
                        st.rerun()
        
        # ---------------------------------
        # DDL File
        # ---------------------------------
        col1, col2, col3 = st.columns([0.8,0.8,16], vertical_alignment='center', gap=None)
        with col1:
            st.container(width='stretch')
        with col2:
            st.write('├──')
        with col3:
            with st.expander(st.session_state.ddl_file_name):
                ddl_code_editor_dict = code_editor(
                    st.session_state.ddl_code, 
                    lang='sql', 
                    height=[10, 20], 
                    response_mode="blur", 
                    key="ddl_code_editor", 
                    allow_reset=True,
                    buttons=code_editor_custom_btns,
                    options={
                        "wrap": True, 
                        "showLineNumbers": True, 
                        "cursorStyle": "smooth"},
                )

                if ddl_code_editor_dict.get('id') != '' and ddl_code_editor_dict.get('id') is not None:
                    if ddl_code_editor_dict.get('id') != st.session_state.ddl_code_editor_id:
                        st.session_state.ddl_code = ddl_code_editor_dict.get('text')
                        st.session_state.ddl_code_editor_id = ddl_code_editor_dict.get('id')
                        st.rerun()

        # ---------------------------------
        # Dataseed File
        # ---------------------------------
        if st.session_state.is_dim:
            col1, col2, col3 = st.columns([0.8,0.8,16], vertical_alignment='center', gap=None)
            with col1:
                st.container(width='stretch')
            with col2:
                st.write('├──')
            with col3:
                with st.expander(st.session_state.dataseed_file_name):
                    dataseed_code_editor_dict = code_editor(
                        st.session_state.dataseed_code, 
                        lang='sql', 
                        height=[10, 20], 
                        response_mode="blur", 
                        key="dataseed_code_editor", 
                        allow_reset=True,
                        buttons=code_editor_custom_btns,
                        options={
                            "wrap": True, 
                            "showLineNumbers": True, 
                            "cursorStyle": "smooth"},
                    )

                    if dataseed_code_editor_dict.get('id') != '' and dataseed_code_editor_dict.get('id') is not None:
                        if dataseed_code_editor_dict.get('id') != st.session_state.dataseed_code_editor_id:
                            st.session_state.dataseed_code = dataseed_code_editor_dict.get('text')
                            st.session_state.dataseed_code_editor_id = dataseed_code_editor_dict.get('id')
                            st.rerun()

        # ---------------------------------
        # SP File
        # ---------------------------------
        col1, col2, col3 = st.columns([0.8,0.8,16], vertical_alignment='center', gap=None)
        with col1:
            st.container(width='stretch')
        with col2:
            st.write('├──')
        with col3:
            with st.expander(st.session_state.sp_file_name):
                sp_code_editor_dict = code_editor(
                    st.session_state.sp_code, 
                    lang='sql', 
                    height=[25, 25], 
                    response_mode="blur", 
                    key="sp_code_editor", 
                    allow_reset=True,
                    buttons=code_editor_custom_btns,
                    options={
                        "wrap": True, 
                        "showLineNumbers": True, 
                        "cursorStyle": "smooth"},
                )

                if sp_code_editor_dict.get('id') != '' and sp_code_editor_dict.get('id') is not None:
                    if sp_code_editor_dict.get('id') != st.session_state.sp_code_editor_id:
                        st.session_state.sp_code = sp_code_editor_dict.get('text')
                        st.session_state.sp_code_editor_id = sp_code_editor_dict.get('id')
                        st.rerun()


        # ---------------------------------
        # Display the Delpoyer Widget
        # ---------------------------------
        col1, col2, col3 = st.columns([0.8,0.8,16], vertical_alignment='center', gap=None)
        with col1:
            st.container(width='stretch')
        with col2:
            st.write('└──')
        with col3:
            with st.container(border=True):
                st.subheader(f"Deploy :{'green' if st.session_state.is_fact else 'blue'}[{st.session_state.table_name.upper()}]")
                st.caption('Deploy the generated scripts to Snowflake! Project\'s DEV Database is Recommended.')
                with st.container(horizontal=True, gap='small'):
                    deploy_scripts = st.button(
                        "Deploy Scripts", 
                        width=220, 
                        icon=":material/cloud_upload:"
                    )
                    
                    with st.popover('Download', icon=':material/download:', width=220):
                        with st.container(width=350):
                            st.subheader(':blue[:material/folder_zip: Download ZIP]')
                            zip_name = st.text_input(
                                'Name your ZIP File', 
                                icon=':material/folder_zip:', 
                                label_visibility='collapsed', 
                                value=st.session_state.table_name,
                                disabled=True,
                            )
                            st.caption('Download the generated scripts as a `zip` file!')
                            st.download_button(
                                label="Download ZIP",
                                data=generate_zip(st.session_state.sequence_file_name, st.session_state.sequence_code, st.session_state.ddl_file_name, st.session_state.ddl_code, st.session_state.sp_file_name, st.session_state.sp_code) if st.session_state.is_fact else generate_zip(st.session_state.sequence_file_name, st.session_state.sequence_code, st.session_state.ddl_file_name, st.session_state.ddl_code, st.session_state.sp_file_name, st.session_state.sp_code, st.session_state.dataseed_file_name, st.session_state.dataseed_code),
                                file_name=f"{zip_name}.zip",
                                mime="application/zip",
                                icon=":material/download:",
                                on_click='ignore'
                            )
        
            if deploy_scripts:
                try:
                    deployment_result = st.empty()
                    with deployment_result:
                        with st.status('Deploying Scripts'):
                            role = get_role_for_database_selected()
                            st.session_state.deployment_session = retrieve_deployment_session(st.session_state.project_database, role)

                            with st.spinner(f'{st.session_state.sequence_file_name}', show_time=True):
                                st.session_state.deployment_session.sql(st.session_state.sequence_code).collect()

                            # Deploy Table
                            with st.spinner(f'{st.session_state.ddl_file_name}', show_time=True):
                                ddl_queries = string_splitter(st.session_state.ddl_code)
                                for query in ddl_queries[:-1]:
                                    # if not query.strip().startswith("ALTER SESSION"):
                                    st.session_state.deployment_session.sql(query.strip()).collect()

                            if st.session_state.is_dim:
                                with st.spinner(f'{st.session_state.sequence_file_name}', show_time=True):
                                    st.session_state.deployment_session.sql(st.session_state.dataseed_code).collect()

                            # Deploy SP
                            with st.spinner(f'{st.session_state.sp_file_name}', show_time=True):
                                st.session_state.deployment_session.sql(st.session_state.sp_code).collect()

                        st.success(f'{st.session_state.table_name.upper()} was deployed successfully!', icon=':material/award_star:')            
            
                except Exception as e:
                    with deployment_result:
                        display_error(e, 'Deployment Failed')


        # ---------------------------------
        # Display the SP Caller
        # ---------------------------------
        st.html("<h3>" "</h3>")
        st.html("<h3>" "</h3>")
        with st.form('sp_caller'):
            name_idx = st.session_state.sp_file_name.find('SP_')
            ext_idx = st.session_state.sp_file_name.find('.sql')
            stored_proc_name = st.session_state.sp_file_name[name_idx:ext_idx]
            
            st.subheader(f':material/terminal: Call :orange[{stored_proc_name.upper()}]')
            st.caption('Call your Deployed Stored Procedure to populate your table with data')
            st.code(f'CALL EDW.{stored_proc_name}', language='sql')
            st.write('`SCROLL DOWN ↓ TO SEE MORE PARAMETERS:`')

            paramCol, buttonCol = st.columns([25,16])
            with paramCol:
                with st.container(height=55, width=950, border=False):
                    # Parameter - 1
                    col1, col2, col3 = st.columns([0.5,0.9,12], vertical_alignment='center', gap=None)
                    with col1:
                        st.container(width='stretch')
                    with col2:
                        st.write('└──')
                    with col3:
                        subCol1, subCol2 = st.columns([6,7])
                        with subCol1:
                            st.text_input('sourceDatabaseName', value='P_SOURCEDATABASENAME', label_visibility='collapsed', disabled=True)
                        with subCol2:
                            sourceDatabaseName = st.text_input('sourceDatabaseName', value='ED_SOURCE', label_visibility='collapsed')
                    
                    # Parameter - 2
                    col1, col2, col3 = st.columns([0.5,0.9,12], vertical_alignment='center', gap=None)
                    with col1:
                        st.container(width='stretch')
                    with col2:
                        st.write('└──')
                    with col3:
                        subCol1, subCol2 = st.columns([6,7])
                        with subCol1:
                            st.text_input('batchLogID', value='P_BATCHLOGID', label_visibility='collapsed', disabled=True)
                        with subCol2:
                            batchLogID = st.text_input('batchLogID', value='-1', label_visibility='collapsed')
                    
                    # Parameter - 3
                    col1, col2, col3 = st.columns([0.5,0.9,12], vertical_alignment='center', gap=None)
                    with col1:
                        st.container(width='stretch')
                    with col2:
                        st.write('└──')
                    with col3:
                        subCol1, subCol2 = st.columns([6,7])
                        with subCol1:
                            st.text_input('pipelineID', value='P_PIPELINEID', label_visibility='collapsed', disabled=True)
                        with subCol2:
                            pipelineID = st.text_input('pipelineID', value='-9999', label_visibility='collapsed')
                    
                    # Parameter - 4
                    col1, col2, col3 = st.columns([0.5,0.9,12], vertical_alignment='center', gap=None)
                    with col1:
                        st.container(width='stretch')
                    with col2:
                        st.write('└──')
                    with col3:
                        subCol1, subCol2 = st.columns([6,7])
                        with subCol1:
                            st.text_input('startDateTime', value='P_STARTDATETIME', label_visibility='collapsed', disabled=True)
                        with subCol2:
                            startDateTime = st.text_input('startDateTime', value='1900-01-01 00:00:00', label_visibility='collapsed')
                    
                    # Parameter - 5
                    col1, col2, col3 = st.columns([0.5,0.9,12], vertical_alignment='center', gap=None)
                    with col1:
                        st.container(width='stretch')
                    with col2:
                        st.write('└──')
                    with col3:
                        subCol1, subCol2 = st.columns([6,7])
                        with subCol1:
                            st.text_input('endDateTime', value='P_ENDDATETIME', label_visibility='collapsed', disabled=True)
                        with subCol2:
                            endDateTime = st.text_input('endDateTime', value='2025-08-28 21:12:40', label_visibility='collapsed')
                    
                    # Parameter - 6
                    col1, col2, col3 = st.columns([0.5,0.9,12], vertical_alignment='center', gap=None)
                    with col1:
                        st.container(width='stretch')
                    with col2:
                        st.write('└──')
                    with col3:
                        subCol1, subCol2 = st.columns([6,7])
                        with subCol1:
                            st.text_input('processDateTime', value='P_PROCESSDATETIME', label_visibility='collapsed', disabled=True)
                        with subCol2:
                            processDateTime = st.text_input('processDateTime', value='SYSDATE()', label_visibility='collapsed')    

                    st.html('<div></div>')

            with buttonCol:
                call_sp = st.form_submit_button(f'CALL STORED PROC', width='stretch', icon=':material/call_log:')                

            if call_sp:
                query = f"CALL EDW.{stored_proc_name}(P_SOURCEDATABASENAME=>'{sourceDatabaseName.strip()}', P_BATCHLOGID => '{batchLogID.strip()}', P_PIPELINEID => '{pipelineID.strip()}',  P_STARTDATETIME => '{startDateTime.strip()}', P_ENDDATETIME => '{endDateTime.strip()}', P_PROCESSDATETIME => {processDateTime})"
                try:
                    with st.empty():
                        with st.status(f'Calling {stored_proc_name.upper()}'):
                            st.session_state.deployment_session.sql(query).collect()
                        st.success(f"Successfully Populated **{st.session_state.table_name}** with Data!", icon=':material/task_alt:')
                    st.snow()
                except Exception as e:
                    display_error(e, 'Stored Procedure execution time')

    # Required if you already have generated scripts, and then click the generate button again
    # The following triggers a rerun so that new scripts can be generated with updated info
    if st.session_state.retrigger_script_generation:
        st.session_state.retrigger_script_generation = False
        st.session_state.regenerate_scripts = True

        st.session_state.scripts_generated = False

        st.rerun()

with save_popover:
    if st.session_state.table_name is not None:
        st.session_state.default_save_name = f'{st.session_state.table_name}'
        disabled_state = False
    else:
        st.session_state.default_save_name = 'You have Nothing to Save :('
        disabled_state = True
    
    with st.container(width=450, key='save_popover'):
        save_state_header = st.empty()
        save_state_header.subheader(':green[:material/save: SAVE STATE]')
        save_name = st.text_input(
            'Name your Save File', 
            icon=':material/save:', 
            label_visibility='collapsed', 
            value=st.session_state.default_save_name, 
            disabled=disabled_state
        )

        save_state_caption = st.empty()
        save_state_caption.caption('Save the current Dimensional Modeler State for later use!')
        st.session_state.save_bottom_container = st.empty()
        with st.session_state.save_bottom_container.container(horizontal_alignment='left', horizontal=True):
            trigger_save = st.button('Save', icon=':material/save:', width=160,  disabled=st.session_state.sttm_df is None)
            manage_saves_global_save = st.button('Manage Saves', icon=':material/save:', type='tertiary', key="Manage Saves for Save")

        if trigger_save:
            with st.session_state.save_bottom_container:
                with st.status('Saving State'):
                    with st.spinner('Writing State to Database', show_time=True):
                        try:
                            
                            if check_save_exist(save_name):
                                save_state(save_name)
                            
                            else:
                                save_state_header.subheader(':red[:material/edit_square: ALREADY EXISTS]')
                                save_state_caption.caption('A State with the same name already exists, would you like to overwrite?')
                                with st.session_state.save_bottom_container:
                                    with st.container(horizontal=True):
                                        st.button('Overwrite', icon=':material/edit_square:', width='stretch', on_click=trigger_overwrite_save)
                                        st.button('Cancel', icon=':material/close:', width='stretch')
                                st.stop()
                        
                        except Exception as e:
                            with st.session_state.save_bottom_container:
                                display_error(e, 'Saving Failed')
                            st.stop()
                
                st.session_state.save_list = load_save_list()
                st.session_state.show_save_success = True
                st.rerun()

        if manage_saves_global_save:
            manage_saves_dialog()

        if st.session_state.overwrite_save:
            st.session_state.overwrite_save = False
            with st.session_state.save_bottom_container:
                with st.status('Saving State'):
                    with st.spinner('Writing State to Database', show_time=True):
                        try:
                            save_state(save_name, overwrite=True)
                        except Exception as e:
                            with st.session_state.save_bottom_container:
                                display_error(e, 'Saving Failed')
                            st.stop()
                st.session_state.save_list = load_save_list()
                st.session_state.show_save_success = True
                st.rerun()

        if st.session_state.show_save_success:
            with st.session_state.save_bottom_container:
                st.success(f'Successfully Saved {save_name}!', icon=':material/done_all:')
            st.session_state.show_save_success = False
