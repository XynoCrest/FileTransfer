import pandas as pd

def wrap_columns(column_string, max_length, indent_size):
    """
    Wraps a comma-separated list of columns so that no line exceeds max_length.
    Each line ends with '||' except the last.
    All lines except the first are indented.
    """
    indent = " " * indent_size
    columns = [col.strip() for col in column_string.split(",")]
    lines = []
    current_line = ""
    for col in columns:
        if current_line:
            test_line = current_line + ", " + col
        else:
            test_line = col
        if len(test_line) > max_length:
            lines.append("'" + current_line + "," + "'" + " ||")
            current_line = col
        else:
            current_line = test_line
    if current_line:
        lines.append("'" + current_line + "'")
    for i in range(1, len(lines)):
        lines[i] = indent + lines[i]
    return "\n".join(lines)


def generate_dim_scripts(sttm, table_description, transformation_query):
    object_name = sttm["Table"].iat[0].upper()
    
    # A list of statements to be generated and merged to generate the sequence file
    sequence_statements = []

    # Variable to be appeneded to, to generate the DDL Script
    ddl_statements = (
        'ALTER SESSION SET QUOTED_IDENTIFIERS_IGNORE_CASE = FALSE;\n\n' +
        f'CREATE OR ALTER TABLE EDW.{object_name} (\n'
    )

    # Part of the DDL script comment section
    comment_sql = f"ALTER SESSION SET QUOTED_IDENTIFIERS_IGNORE_CASE = TRUE;\n\n"
    table_comment = f'$${table_description}$$' if table_description != '' else f"$$description for table {object_name}$$"
    comment_sql += f"ALTER TABLE EDW.{object_name} SET COMMENT = {table_comment};\n\n"

    for row in sttm.itertuples(index=False):
        if pd.isna(row.Column_Name):
            continue
        
        target_column = str(row.Column_Name).strip()
        description = row.Description if pd.notna(row.Description) else f'description for {target_column}' 
        data_type = str(row.Target_Data_Type).strip().upper()

        if "__" in target_column:
            continue

        if data_type == "PK":
            # Generate the Primary Key SID column in the Table DDL
            sid_type = f"NUMBER DEFAULT EDW.SEQ_{object_name}_{target_column}.NEXTVAL"

            # Generates the Sequence Statements for the sequence DDL
            sequence_statement = f'CREATE SEQUENCE IF NOT EXISTS EDW.SEQ_{object_name}_{target_column}\n'
            sequence_statement += f'\tSTART WITH 1\n'
            sequence_statement += f'\tINCREMENT BY 1\n'
            sequence_statement += f'COMMENT = \'FOR TABLE-COLUMN SEQ_{object_name}.{target_column}\';'
            sequence_statements.append(sequence_statement)
            sequence_sid = target_column
        else:
            sid_type = data_type

        ddl_statements += f'"{target_column}" {sid_type}{" NOT NULL" if str(row.Mandatory).strip().upper() == "Y" else ""},\n'

        comment_sql += f"COMMENT ON COLUMN EDW.{object_name}.{target_column} IS $${description}$$;\n\n"

    # Used Later for Dataseed
    audit_columns = """
      "__CurrentFlag", 
      "__DeletedFlag", 
      "__EffectiveStartDateTime", 
      "__EffectiveEndDateTime", 
      "__LateArrivingFlag", 
      "__BusinessKeyHash", 
      "__Type1Hash", 
      "__Type2Hash", 
      "__CreatedBatchLogID", 
      "__UpdatedBatchLogID", 
      "__CreatedPipelineID", 
      "__UpdatedPipelineID", 
      "__CreateDateTime", 
      "__UpdateDateTime"
    """

    audit_columns_definitions = (
        '"__CurrentFlag" BOOLEAN NOT NULL,\n' + 
        '"__DeletedFlag" BOOLEAN NOT NULL,\n' +
        '"__LateArrivingFlag" BOOLEAN NOT NULL,\n' +
        '"__BusinessKeyHash" BINARY NOT NULL,\n' +
        '"__Type1Hash" BINARY NOT NULL,\n' +
        '"__Type2Hash" BINARY NOT NULL,\n' +
        '"__EffectiveStartDateTime" TIMESTAMP_NTZ NOT NULL,\n' +
        '"__EffectiveEndDateTime" TIMESTAMP_NTZ NOT NULL,\n' +
        '"__CreatedBatchLogID" VARCHAR NOT NULL,\n' +
        '"__UpdatedBatchLogID" VARCHAR NOT NULL,\n' +
        '"__CreatedPipelineID" VARCHAR NOT NULL,\n' +
        '"__UpdatedPipelineID" VARCHAR NOT NULL,\n' +
        '"__CreateDateTime" TIMESTAMP_NTZ NOT NULL,\n' +
        '"__UpdateDateTime" TIMESTAMP_NTZ NOT NULL'
    )

    audit_column_comments = (
        f"COMMENT ON COLUMN EDW.{object_name}.__CurrentFlag  IS 'The row of data for a SID that is current and that represents the latest updates to individual column data values';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__DeletedFlag IS 'The row of data for that has been superseded by subsequent updates to a specific column data value';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__LateArrivingFlag IS 'Indicates where certain data values were not available at the initial generation of the row of data, and where such data values subsequently arrived and were added later';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__BusinessKeyHash IS 'The business key data value (string of characters) for a row of data, transformed into a shorter, fixed-length value or key that represents and makes it easier to find or employ the original string.';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__Type1Hash IS 'The SCD type 1 data value (string of characters) for a row of data, transformed into a shorter, fixed-length value or key that represents and makes it easier to find or employ the original string.';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__Type2Hash IS 'The SCD type 2 data value (string of characters) for a row of data, transformed into a shorter, fixed-length value or key that represents and makes it easier to find or employ the original string.';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__EffectiveStartDateTime IS 'The date that the row of data became effective /valid';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__EffectiveEndDateTime IS 'The date that the row of data ceased to be effective /valid';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__CreatedBatchLogID IS 'The identifying characters of the data batch that contained and generated (created) the row of data';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__UpdatedBatchLogID IS 'The identifying characters of the data batch that contained updates to an existing row of data';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__CreatedPipelineID IS 'The identifying characters of the data pipeline that contained and generated (created) the row of data';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__UpdatedPipelineID IS 'The identifying characters of the data pipeline that contained updates to an existing row of data';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__CreateDateTime IS 'The date and time that the row of data was created in the EDW';\n\n" + 
        f"COMMENT ON COLUMN EDW.{object_name}.__UpdateDateTime IS 'The date and time that the row of data was updated in the EDW';"
    )

    ddl_statements = ddl_statements.rstrip(',\n') + ',\n' + audit_columns_definitions
    # Ending Parenthesis
    ddl_statements += '\n);\n'

    ddl = ddl_statements + '\n' + comment_sql + audit_column_comments
    sequence = '\n'.join(sequence_statements)

    # -------------------------------
    # Stored Procedure
    # -------------------------------
    business_key_columns = []
    type_1_columns = []
    
    view_statements = []
    processed_views = []
    source_query_statement = []
    cte_statements = []

    for row in sttm.itertuples(index=False):
        # Generate View Statements
        if pd.notna(row.Schema) and pd.notna(row.ViewName):
            # Check if the same view has already been processed to ignore duplicate sources
            view_already_processed = False
            for view in processed_views:
                if f'{row.Schema}.{row.ViewName}' == view:
                    view_already_processed = True
                    break

            if not view_already_processed:
                view_statements.append(f'\n    LET v_SourceQuery_{row.ViewName} VARCHAR; ')

                # Generate Source Query Statements
                if str(row.Schema).strip() == "EDW":
                    p_DatabaseNamevalue = "v_FactDatabaseName"
                else:
                    p_DatabaseNamevalue = "p_SourceDatabaseName"
                
                data_read_type = row.Data_Read_Type if pd.notna(row.Data_Read_Type) else 'type_i_full_load'

                if data_read_type == 'type_i_full_load':
                    source_query_statement.append(f"""
        v_SourceQuery_{row.ViewName} := (CALL ED_UTILITIES.COMMON.sp_Generate_SourceSelectQuery(
                                                            p_DatabaseName => :{p_DatabaseNamevalue},
                                                            p_SchemaName => '{row.Schema}',
                                                            p_ObjectName => '{row.ViewName}',
                                                            p_DataReadType => 'type_i_full_load'));\n""")

                elif data_read_type == 'regular_incremental':
                    source_query_statement.append(f"""
        v_SourceQuery_{row.ViewName} := (CALL ED_UTILITIES.COMMON.sp_Generate_SourceSelectQuery (
                                                            p_DatabaseName => :{p_DatabaseNamevalue},
                                                            p_SchemaName => '{row.Schema}',
                                                            p_ObjectName => '{row.ViewName}',
                                                            p_DataReadType => 'regular_incremental',
                                                            p_AdditionalColumnList => :v_AdditionalColumnList,
                                                            p_ProcessStartDatetime => :p_StartDateTime,
                                                            p_ProcessEndDatetime => :p_EndDateTime,
                                                            p_SourceDatetimeColumn => '{row.SourceDatetimeColumn}'));\n""")

                elif data_read_type == 'type_ii_incremental_join_right_side':
                    source_query_statement.append(f"""
        v_SourceQuery_{row.ViewName} := (CALL ED_UTILITIES.COMMON.sp_Generate_SourceSelectQuery (
                                                                p_DatabaseName => :{p_DatabaseNamevalue},
                                                                p_SchemaName => '{row.Schema}',
                                                                p_ObjectName => '{row.ViewName}',
                                                                p_DataReadType => 'type_ii_incremental_join_right_side'));\n""")
                
                elif data_read_type == 'type_i_incremental_join_right_side':
                    source_query_statement.append(f"""
        v_SourceQuery_{row.ViewName} := (CALL ED_UTILITIES.COMMON.sp_Generate_SourceSelectQuery (
                                                                p_DatabaseName => :{p_DatabaseNamevalue},
                                                                p_SchemaName => '{row.Schema}',
                                                                p_ObjectName => '{row.ViewName}',
                                                                p_DataReadType => 'type_i_incremental_join_right_side',
                                                                p_ListOfPartitionValues => :v_ListOfPartitionValues));\n""")
                
                else:
                    source_query_statement.append(f"""
        -- ERROR: Unsupported DataReadType '{data_read_type}' for view '{row.ViewName}'
                """)
                    
                if pd.notna(row.Alias):
                    cte_statements.append(f"{row.Alias} AS ('|| v_SourceQuery_{row.ViewName} ||')")
                else:
                    cte_statements.append(f"{row.ViewName} AS ('|| v_SourceQuery_{row.ViewName} ||')")
                
                processed_views.append(f'{row.Schema}.{row.ViewName}')
        
        if pd.isna(row.Column_Name):
            continue

        # Retrieve Business Key Columns from the STTM
        if str(row.Business_Key).strip().upper() == 'Y' and str(row.Target_Data_Type).strip().upper() != 'PK':
            business_key_columns.append(row.Column_Name)

        # Retrieve Type 1 Columns from the STTM
        if not row.Column_Name.startswith("__") and str(row.Type1Col).strip().upper() == 'Y':
            type_1_columns.append(row.Column_Name)
    
    view_statements_str = '\n'.join(view_statements + source_query_statement)
    business_key_columns = ', '.join(business_key_columns) if business_key_columns else 'NULL'
    type_1_columns = ', '.join(type_1_columns) if type_1_columns else 'NULL'
    
    cte_sql = f"""
    v_StagingQuery := 'CREATE OR REPLACE TEMPORARY TABLE ' || v_StagingFullTableName || ' AS (
                    WITH {', '.join(cte_statements)},
                        TransformationQuery AS (' || v_TransformationQuery || ')
                    SELECT ' || v_DataColumnList || ',
                        ED_UTILITIES.COMMON.fn_Calculate_Hash(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(' ||
                                v_BusinessKeySortedList || '), ''|'')) AS "__BusinessKeyHash",
                        ED_UTILITIES.COMMON.fn_Calculate_Hash(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(' || 
                                v_Type1ColumnSortedList || '), ''|'')) AS "__Type1Hash",
                                ' || v_DeletedFlagColumnString || ',
                        ED_UTILITIES.COMMON.fn_Calculate_Hash(ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(' ||
                                v_Type2ColumnSortedList || '), ''|'')) AS "__Type2Hash",
                        CAST(''' || :p_ProcessDateTime || ''' AS TIMESTAMP_NTZ) AS "__CreateDateTime",
                        CAST(' || v_CreationDatetimeColumn || ' AS TIMESTAMP_NTZ) AS "__DataCreationDateTime",
                        CAST(' || v_ModificationDatetimeColumn || ' AS TIMESTAMP_NTZ) AS "__DataModificationDateTime"
                    FROM   TransformationQuery
                    )';
    """
    
    with open('Dim_SP_Template.sql', 'r') as file:
        sp_template = file.read()

    sp = sp_template.format(
        object_name = object_name,
        table_schema = sttm["TableSchemaName"].iat[0].upper(),
        business_key_columns = wrap_columns(business_key_columns, max_length=90, indent_size=31),
        type_1_columns = wrap_columns(type_1_columns, max_length=96, indent_size=31),
        source_create_datetime_column = sttm["Source_Create_Datetime_Column"].iat[0].strip() if sttm["Source_Create_Datetime_Column"] is not None else 'sysdate()' ,
        source_update_datetime_column = sttm["Source_Update_Datetime_Column"].iat[0].strip() if sttm["Source_Update_Datetime_Column"] is not None else 'sysdate()',
        view_statements = view_statements_str,
        custom_transformation = transformation_query,
        CteSql = cte_sql
    )

    # -------------------------------
    # Data seed
    # -------------------------------
    # Format business key cols list
    formatted_key_columns = [col.strip() for col in business_key_columns.strip().split(',') if col.strip()]
    formatted_key_columns = [f'      "{sequence_sid}",']+ [f'      "{col}",' for col in formatted_key_columns]
    formatted_key_columns = '\n'.join(formatted_key_columns)

    # Generate Unavailable strings
    Numberofkeys = len(business_key_columns.split(','))
    numberofnotfound = ', '.join(["'Not Found'"] * Numberofkeys)
    numberofna = ', '.join(["'N/A'"] * Numberofkeys)
    numberofunkown = ', '.join(["'Unknown'"] * Numberofkeys)

    dataseed = f"""EXECUTE IMMEDIATE $$
BEGIN
  BEGIN TRANSACTION;

  DELETE FROM EDW.{object_name}
   WHERE "{sequence_sid}" IN (-1, -2, -3);

  INSERT INTO EDW.{object_name} (
{formatted_key_columns}{audit_columns}
  )
  SELECT
      -3,  {numberofnotfound},
       1, 0, '1900-01-01', '2999-12-31 23:59:59', 0, CAST('FFFFFFFF' AS VARBINARY(64)), 
       CAST('FFFFFFFF' AS VARBINARY(64)), CAST('FFFFFFFF' AS VARBINARY(64)),  -1, -1, -1, -1, '1900-01-01', '1900-01-01'

  UNION ALL

  SELECT
      -2,  {numberofna},
       1, 0, '1900-01-01', '2999-12-31 23:59:59', 0, CAST('FFFFFFFF' AS VARBINARY(64)), 
       CAST('FFFFFFFF' AS VARBINARY(64)), CAST('FFFFFFFF' AS VARBINARY(64)),  -1, -1, -1, -1, '1900-01-01', '1900-01-01'

  UNION ALL

  SELECT
      -1,  {numberofunkown},
       1, 0, '1900-01-01', '2999-12-31 23:59:59', 0, CAST('FFFFFFFF' AS VARBINARY(64)), 
       CAST('FFFFFFFF' AS VARBINARY(64)), CAST('FFFFFFFF' AS VARBINARY(64)),  -1, -1, -1, -1, '1900-01-01', '1900-01-01'
  ;

  COMMIT;
END;
$$;
"""
    sequence_file_name = f'R__000_EDW_SEQ_{object_name}_{sequence_sid}.sql'
    ddl_file_name = f'R__020_EDW_{object_name}.sql'
    dataseed_file_name = f'R__210_EDW_Populate_{object_name}.sql'
    sp_file_name = f'R__100_EDW_SP_LOAD_{object_name}.sql'

    return (sequence_file_name, sequence), (ddl_file_name, ddl), (dataseed_file_name, dataseed), (sp_file_name, sp)