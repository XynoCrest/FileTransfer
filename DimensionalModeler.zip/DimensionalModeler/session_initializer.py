from snowflake.snowpark import Session

def retrieve_session():
  connection_parameters = {
      "account": "SUNCOR-ENTERPRISEDATA",
      "user": "C1.BSAHA@SUNCOR.ONMICROSOFT.COM",
      "authenticator": "externalbrowser",
      "database": "PRJ_COSTTRANSPARENCY_DEV",
      "schema": "STREAMLIT",
      "warehouse": "WHS_COSTTRANSPARENCY",
      "role": "RG-APP-SF-COSTTRANSPARENCY",
  }
  session = Session.builder.configs(connection_parameters).create()
  return session

def retrieve_deployment_session(database, role):
  connection_parameters = {
      "account": "SUNCOR-ENTERPRISEDATA",
      "user": "C1.BSAHA@SUNCOR.ONMICROSOFT.COM",
      "authenticator": "externalbrowser",
      "database": database,
      "schema": "EDW",
      "warehouse": "WHS_COSTTRANSPARENCY",
      "role": role,
  }
  session = Session.builder.configs(connection_parameters).create()
  return session
