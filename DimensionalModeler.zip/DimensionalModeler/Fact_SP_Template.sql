/*  ================================================================================================================
    TO DEVELOPERS:

    Use the following sample as a template for creating a stored procedure to load a Fact table.
    You will only need to update certain sections of the code to customize the stored procedure for your need.

    Update the following:
        - Revision History
        - Stored Procedure Name - including the v_StoredProcedureName variable
        - Section to set Object Names and variables
        - Section to define the Source and Transformation queries
        - Section to create the temporary staging table
        - Section on late arriving, if applicable

    Key Notes:
    - Review the final code and make adjustments as applicable for your table.
    - Make sure you are following the Coding Standards in your development, e.g. naming convention, indentation,
        line lengths (you can use the horizontal lines provided in the comments as a guide to limit the length
        of a line in your code, i.e. 120 characters), etc.
    - Provide as much inline documentation as you can so your code is easy to follow and understand.
    - Ensure the stored procedure does not exceed Snowflake’s recommended 100KB size limit.
    - Strive for cost efficiency in your solution design and coding strategy.

    REMOVE THIS COMMENT BLOCK IN YOUR FINAL VERSION.
    ================================================================================================================
*/

CREATE OR REPLACE PROCEDURE EDW.sp_Load_{object_name} (
    p_SourceDatabaseName    VARCHAR,
    p_BatchLogID            VARCHAR DEFAULT '-1',
    p_PipelineID            VARCHAR DEFAULT '-9999',
    p_StartDateTime         TIMESTAMP_NTZ DEFAULT NULL,
    p_EndDateTime           TIMESTAMP_NTZ DEFAULT NULL,
    p_ProcessDateTime       TIMESTAMP_NTZ DEFAULT SYSDATE()
)
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
/*  -------------------------------------------------------------------------------------------------------------------
    Loads data from a streaming source to a target Silver-layer table.

    PARAMETERS:
    - p_SourceDatabaseName - name of the Source table/view database
    - p_BatchLogID - EDO ADF Run ID for the batch
    - p_PipelineID - EDO ADF Run ID for the pipeline
    - p_StartDateTime - start datetime used to filter the source data for incremental load. This is the
            NextStartDateTimeUTC for the pipeline from the EDO MainControlTable
    - p_EndDateTime - end datetime used to filter the source data for incremental load. This is the earlier value
            between the pipeline NextEndDateTimeUTC from the EDO MainControlTable or the trigger datetime.
    - p_ProcessDateTime - pipeline trigger datetime

    OUTPUT:
    - Audit counts from the load process.

    REVISION HISTORY:  (Retain 1st and last 3 revisions only, remove older revision notes.)
    DATE          | MODIFIED BY         | DESCRIPTION
    Feb 20, 2025  | Tharun K            | Initial creation
    May 20, 2025  | E. Lagmay           | Updated code sections and queries.
    -------------------------------------------------------------------------------------------------------------------
*/
DECLARE
    -- Default variables
    v_StoredProcedureName           VARCHAR := 'sp_Load_{object_name}';
    v_ExecutionStartDatetime        TIMESTAMP_NTZ := SYSDATE();
    v_ExecutionEndDatetime          TIMESTAMP_NTZ;
    v_TruncateFlag                  BOOLEAN := 0;   -- Flag to indicate if Fact table is to be truncated before load.
    v_ValidateCommitFlag            BOOLEAN := 0;   -- Flag to check if validation of counts is needed before commits.
    v_QueryTag                      VARCHAR;
    v_ResultSet                     RESULTSET;

    -- Stage data variables
    v_StagingSchemaName             VARCHAR;    -- Schema name where the temporary staging table(s) will be created
    v_FactStagingTableName          VARCHAR;    -- Fact staging temporary table name
    v_FactStagingFullTableName      VARCHAR;
    v_SourceStagingTableName        VARCHAR;    -- Source staging temporary table name
    v_SourceStagingFullTableName    VARCHAR;
    v_BusinessKeyColumnList         VARCHAR;
    v_BusinessKeySortedList         VARCHAR;
    v_AdditionalColumnList          VARCHAR;    -- Audit columns to add to the select list when querying the source

    -- Gold data variables
    v_FactDatabaseName              VARCHAR := CURRENT_DATABASE();
    v_FactSchemaName                VARCHAR;
    v_FactTableName                 VARCHAR;
    v_FactFullTableName             VARCHAR;
    v_FactTableSID                  VARCHAR;
    v_SelectColumnList              VARCHAR;    -- List of source columns that will be used for inserts
    v_InsertColumnList              VARCHAR;    -- List of Fact table columns that will be used for inserts
    v_UpdateColumnList              VARCHAR;    -- List of Fact table columns that will be updated
    v_UpdateColumnMappingList       VARCHAR;    -- List of columns used for updating with source = target mapping  
  
    -- Query string variables
    v_SourceDatasetQuery            VARCHAR;
    v_TransformationQuery           VARCHAR;
    v_StagingQuery                  VARCHAR;
    v_FactInsertQuery               VARCHAR;
    v_FactUpdateQuery               VARCHAR;
    v_DeletedFlagColumnString       VARCHAR;    -- String for including the __DeletedFlag column in the staging query

    -- Audit variables
    v_SourceStagingCount            NUMBER := 0;
    v_FactBeforeCount               NUMBER := 0;
    v_FactAfterCount                NUMBER := 0;
    v_NewInsertCount                NUMBER := 0;
    v_NewUpdatecount                NUMBER := 0;
    v_DeleteCount                   NUMBER := 0;
    v_LateArrivingCount             NUMBER := 0;
    v_AuditCountData                VARIANT;

    -- Exception variables
    v_ErrorMessage                  VARCHAR;
    v_LoadException   EXCEPTION (-20010, 'Mismatch between Staging count and Fact changes. Transaction rolled back.');

BEGIN
    -- ================================================================================================================
    -- =                                 CONFIGURE SESSION AND INITIALIZE VARIABLES                                   =
    -- ================================================================================================================
  
    -- ----------------------------------------------------------------------------------------------------------------
    -- Set Session Parameters
    -- ----------------------------------------------------------------------------------------------------------------
    -- Get the current Query Tag for the session
    v_QueryTag := (CALL ED_UTILITIES.COMMON.sp_Get_SessionParameter(p_SessionParameter => 'QUERY_TAG'));
    
    -- Set the Quoted Identifiers Ignore Case parameter to the default TRUE setting
    CALL ED_UTILITIES.COMMON.sp_Set_SessionParameter(p_SessionParameter => 'QUOTED_IDENTIFIERS_IGNORE_CASE',
                                                     p_ParameterValue => TRUE);
    -- Set the new Query Tag for the session
    CALL ED_UTILITIES.COMMON.sp_Set_SessionParameter(p_SessionParameter => 'QUERY_TAG',
                        p_ParameterValue => TO_VARIANT(:v_StoredProcedureName || ' - Batch Log ' || :p_BatchLogID));

    -- ----------------------------------------------------------------------------------------------------------------
    -- Set Gold Object Variables
    -- ----------------------------------------------------------------------------------------------------------------
    v_FactSchemaName := '{table_schema}';
    v_FactTableName := '{object_name}';
    v_FactFullTableName := v_FactSchemaName || '.' || v_FactTableName;
    v_FactTableSID := '{sid_value}';

    -- ----------------------------------------------------------------------------------------------------------------
    -- Set Staging Object Variables
    -- ----------------------------------------------------------------------------------------------------------------
    v_StagingSchemaName := 'EDWSTAGE';

    -- Staging table to store the Fact input dataset from source, without the SIDs from related Dimension tables yet.
    v_SourceStagingTableName := 'tmp_' || v_FactTableName || '_Source';
    v_SourceStagingFullTableName := v_StagingSchemaName || '.' || v_SourceStagingTableName;

    -- Staging table to store the Fact final input dataset, including SIDs from related Dimension tables.
    v_FactStagingTableName := 'tmp_' || v_FactTableName;
    v_FactStagingFullTableName := v_StagingSchemaName || '.' || v_FactStagingTableName;

    -- ----------------------------------------------------------------------------------------------------------------
    -- Set Other Variables
    -- ----------------------------------------------------------------------------------------------------------------
    -- Business key column list
    v_BusinessKeyColumnList := {business_key_columns}; 
    v_BusinessKeySortedList := (CALL ED_UTILITIES.COMMON.sp_Sort_List(p_List => :v_BusinessKeyColumnList));

    -- Additional columns (e.g. audit columns) that need to be added to the source query.
    v_AdditionalColumnList := '';

    -- List of columns to update in the Fact table, excluding SID and audit columns.
    v_UpdateColumnList := {update_table_cols}; 
    -- Flag that indicates whether the Fact table is to be truncated before loading.
    v_TruncateFlag := 0;

    -- Flag that indicates whether validation of transaction counts (updates/inserts) against the staging count is
    -- needed before commiting the transaction.  Set to 1 if validation is intended.
    -- If the counts do not match, the transaction will be rolled back, otherwise, the changes will be committed.
    v_ValidateCommitFlag := 0;

    -- ----------------------------------------------------------------------------------------------------------------
    -- Define Source Query
    -- ----------------------------------------------------------------------------------------------------------------
    -- Define the queries used to read data from the source and will be used to populate the temporary staging tables.

    {view_statements}

    -- ----------------------------------------------------------------------------------------------------------------
    -- Define Transformation Query
    -- ---------------------------------------------------------------------------------------------------------------- 
    /* BEGIN CUSTOM TRANSFORMATION */               
    v_TransformationQuery := '{custom_transformation}';
    /* END CUSTOM TRANSFORMATION */  

    -- Check if the transformation query already contains the __Deleted_Flag column
    IF (CONTAINS(UPPER(:v_TransformationQuery), '__DELETED_FLAG')) THEN
        v_DeletedFlagColumnString := '';
    ELSE
        -- Else assign FALSE as the default value.
        v_DeletedFlagColumnString := '0 AS __DeletedFlag';
    END IF;

    -- ================================================================================================================
    -- =                                          GET SOURCE DATASET                                                  =
    -- ================================================================================================================
    -- Create the temporary staging table.
    {cte_sql}

    EXECUTE IMMEDIATE v_SourceDatasetQuery;

    -- Get Staging count
    v_SourceStagingCount := (SELECT COUNT(*) FROM IDENTIFIER(:v_SourceStagingFullTableName));

    -- Check if there are records to process from the source staging table.
    IF (v_SourceStagingCount > 0) THEN

        -- ============================================================================================================
        -- =                                      HANDLE LATE ARRIVING RECORDS                                        =
        -- ============================================================================================================
        -- Populate this section for any processing needed for late arriving Dimension records.


        -- ============================================================================================================
        -- =                                          CREATE STAGING TABLE                                            =
        -- ============================================================================================================

        -- ------------------------------------------------------------------------------------------------------------
        -- Define Column Lists
        -- ------------------------------------------------------------------------------------------------------------
        -- Get table data columns (excludes SID and audit columns) for insert
        v_InsertColumnList := (CALL ED_UTILITIES.COMMON.sp_Get_SelectOrDataColumns(
                                            p_DatabaseName => :v_FactDatabaseName,
                                            p_SchemaName => :v_FactSchemaName,
                                            p_TableName => :v_FactTableName));


        -- Get table data columns (excludes SID and audit columns) for insert
        v_SelectColumnList := (CALL ED_UTILITIES.COMMON.sp_Get_SelectOrDataColumns(
                                            p_DatabaseName => :v_FactDatabaseName,
                                            p_SchemaName => :v_FactSchemaName,
                                            p_TableName => :v_FactTableName,
                                            p_SelectColumns => TRUE));

        -- Source = Target mapping of columns that will be used in the Fact table update
        v_UpdateColumnMappingList := (CALL ED_UTILITIES.COMMON.sp_Generate_UpdateColumnMappings(
                                            p_UpdateColumnsString=> :v_UpdateColumnList));

        -- ------------------------------------------------------------------------------------------------------------
        -- Create and Populate Staging Table
        -- ------------------------------------------------------------------------------------------------------------
        -- Create Fact staging table using the same structure as the Fact table without the surrogate key SID.
        -- We need to temporarily set the session parameter QUOTED_IDENTIFIERS_IGNORE_CASE as shown below because an 
        -- error occurs with the current usage of EXCLUDE, even when the column name is enclosed in double quotes.
        ALTER SESSION SET QUOTED_IDENTIFIERS_IGNORE_CASE = FALSE;

        v_StagingQuery := 'CREATE OR REPLACE TEMPORARY TABLE ' || v_FactStagingFullTableName ||
                        ' AS SELECT * EXCLUDE "' || v_FactTableSID || '"' ||
                        ' FROM ' || v_FactFullTableName ||
                        ' WHERE  1 = 0';

        EXECUTE IMMEDIATE v_StagingQuery;
        ALTER SESSION SET QUOTED_IDENTIFIERS_IGNORE_CASE = TRUE;

        -- Insert into staging table, including SIDs from related Dimension tables.
        v_StagingQuery := {insert_statement};

        EXECUTE IMMEDIATE :v_StagingQuery;

    -- ================================================================================================================
    -- =                                              LOAD FACT TABLE                                                 =
    -- ================================================================================================================
        -- Get Fact table count before loading.
        v_FactBeforeCount :=  (SELECT COUNT(*) FROM IDENTIFIER(:v_FactFullTableName));
    
        -- If v_TruncateFlag is 1, truncate the Fact table to remove the existing data before inserting new data.
        IF (v_TruncateFlag = 1) THEN
            EXECUTE IMMEDIATE 'TRUNCATE TABLE ' || :v_FactFullTableName;
        END IF;

        -- Begin the Fact table updates.
        BEGIN TRANSACTION;

        -- ------------------------------------------------------------------------------------------------------------
        -- Update Existing Records
        -- ------------------------------------------------------------------------------------------------------------
        v_FactUpdateQuery := 'UPDATE ' || v_FactFullTableName || ' AS target
                              SET  ' || v_UpdateColumnMappingList || ',
                                   target.__DeletedFlag = source.__DeletedFlag,
                                   target.__UpdatedBatchLogID = source.__UpdatedBatchLogID,
                                   target.__UpdateDateTime = source.__UpdateDateTime
                              FROM ' || v_FactStagingFullTableName || ' AS source
                              WHERE target.__FactKeyHash = source.__FactKeyHash ';

        -- Execute the Update statement and capture the count of records updated.
        v_ResultSet := (EXECUTE IMMEDIATE :v_FactUpdateQuery);
        LET cur_Update CURSOR FOR v_ResultSet;
        OPEN cur_Update;
        FETCH cur_Update INTO v_NewUpdatecount;
        CLOSE cur_Update;

        -- ------------------------------------------------------------------------------------------------------------
        -- Insert New Records
        -- ------------------------------------------------------------------------------------------------------------
        v_FactInsertQuery := 'INSERT INTO ' || v_FactFullTableName ||
                             '( ' || v_InsertColumnList || ',
                                    __FactKeyHash,
                                    __DeletedFlag,
                                    __CreatedBatchLogID,
                                    __UpdatedBatchLogID,
                                    __CreateDateTime,
                                    __UpdateDateTime
                            )
                            SELECT ' || v_SelectColumnList || ',
                                    source.__FactKeyHash,
                                    source.__DeletedFlag,
                                    source.__CreatedBatchLogID,
                                    source.__UpdatedBatchLogID,
                                    source.__CreateDateTime,
                                    source.__UpdateDateTime
                            FROM ' || v_FactStagingFullTableName || ' AS source
                                    LEFT OUTER JOIN ' || v_FactFullTableName || ' target
                                        ON target.__FactKeyHash = source.__FactKeyHash
                            WHERE   target.__FactKeyHash IS NULL ';

        -- Execute the Insert statement and capture the count of new records inserted.
        v_ResultSet := (EXECUTE IMMEDIATE :v_FactInsertQuery);
        LET cur_Insert CURSOR FOR v_ResultSet;
        OPEN cur_Insert;
        FETCH cur_Insert INTO v_NewInsertCount;
        CLOSE cur_Insert;

        -- ------------------------------------------------------------------------------------------------------------
        -- Count Deleted Records
        -- ------------------------------------------------------------------------------------------------------------
        -- Count the number of records that marked as deleted in the staging table.
        v_DeleteCount := (SELECT COUNT(*) FROM IDENTIFIER(:v_FactStagingFullTableName) WHERE __DeletedFlag = 1);

        -- ------------------------------------------------------------------------------------------------------------
        -- Commit changes
        -- ------------------------------------------------------------------------------------------------------------
        -- Check if validating the counts before committing the transactions is intended.
        -- If the Staging Count does not match the number of Inserts and Updates made, rollback the transaction.
        IF (v_ValidateCommitFlag = 1 AND ((v_NewInsertCount + v_NewUpdateCount) != v_SourceStagingCount)) THEN
            ROLLBACK;
            RAISE v_LoadException;
        END IF;
        COMMIT;

        -- Capture the records of the Fact table after insert and update operations.
        v_FactAfterCount := (SELECT COUNT(*) FROM IDENTIFIER(:v_FactFullTableName));

    -- Close the IF block of stage count check.
    END IF;

    -- ================================================================================================================
    -- =                                              POST-PROCESSING                                                 =
    -- ================================================================================================================
    v_ExecutionEndDatetime := SYSDATE();

    -- Construct JSON object for the audit counts
    v_AuditCountData := OBJECT_CONSTRUCT_KEEP_NULL(
                        'DatabaseName', v_FactDatabaseName,
                        'SchemaName', v_FactSchemaName,
                        'TableName', v_FactTableName,
                        'StoredProcedure', v_StoredProcedureName,
                        'StagingCount', v_SourceStagingCount,
                        'FactBeforeCount', v_FactBeforeCount,
                        'NewInsertCount', v_NewInsertCount,
                        'NewUpdateCount', v_NewUpdateCount,
                        'FactAfterCount', v_FactAfterCount,
                        'DeleteCount', v_DeleteCount,
                        'LateArrivingCount', v_LateArrivingCount,
                        'ProcessDatetime', :p_ProcessDateTime,
                        'ExecutionStartDatetime', v_ExecutionStartDatetime,
                        'ExecutionEndDatetime', v_ExecutionEndDatetime
                        );

    -- Log the audit counts into the system event table in PRD.
    IF (CURRENT_DATABASE() = 'SUNCOR') THEN
        CALL ED_UTILITIES.COMMON.sp_Log_SystemEvent(p_SeverityLevel => 'INFO', p_Message => :v_AuditCountData);
    END IF;

    -- Set the session Query Tag back to the previous value. This is needed so that the previous query tag is used for
    -- any subsequent queries, especially if this stored proc was called from a wrapper or another stored procedure. 
    CALL ED_UTILITIES.COMMON.sp_Set_SessionParameter(p_SessionParameter => 'QUERY_TAG',
                    p_ParameterValue =>  TO_VARIANT(:v_QueryTag));
    
    RETURN (v_AuditCountData);

    -- ----------------------------------------------------------------------------------------------------------------
    -- Exception handling - log the error details in the event table and raise the error
    -- ----------------------------------------------------------------------------------------------------------------
    EXCEPTION
        WHEN v_LoadException THEN
            v_ErrorMessage := 'Error encountered - DatabaseName: ' || v_FactDatabaseName ||
                                    ', SchemaName: ' || v_FactSchemaName || ', TableName: ' || v_FactTableName ||
                                    ', StoredProcedure: ' || v_StoredProcedureName ||
                                    ', SQLCODE: ' || SQLCODE || ', SQLERRM: ' || SQLERRM ||
                                    ', SQLSTATE: ' || SQLSTATE || ', TIMESTAMP : ' || SYSDATE();
            CALL ED_UTILITIES.COMMON.sp_Log_SystemEvent(p_SeverityLevel => 'ERROR', p_Message => :v_ErrorMessage);
            RAISE;
        WHEN OTHER THEN
            v_ErrorMessage := 'Error encountered - DatabaseName: ' || v_FactDatabaseName ||
                                    ', SchemaName: ' || v_FactSchemaName || ', TableName: ' || v_FactTableName ||
                                    ', StoredProcedure: ' || v_StoredProcedureName ||
                                    ', SQLCODE: ' || SQLCODE || ', SQLERRM: ' || SQLERRM ||
                                    ', SQLSTATE: ' || SQLSTATE || ', TIMESTAMP : ' || SYSDATE();

            CALL ED_UTILITIES.COMMON.sp_Log_SystemEvent(p_SeverityLevel => 'ERROR', p_Message => :v_ErrorMessage);
            RAISE;
END;
$$;