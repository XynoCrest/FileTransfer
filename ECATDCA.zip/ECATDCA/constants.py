TABLE_NAME = 'ECAT.ECAT_TERMINALPROFILE_BEN'

TERMINALTYPE_OPTIONS = ["CAMP", "OFFSITE", "ONSITE", "OTHER", "UNKNOWN"]

HIDDEN_COLUMNS = [
    "BATCHLOGID",
    "CREATEDUSERID",
    "CREATEDDATETIME",
    "LATEARRIVINGFLAG",
    "TIMEATT",
    "COUNTSFORSITE",
    "TIMEZONESHORTNAME",
]

# HIDDEN_COLUMNS = []

TIME_ZONE_OPTIONS = [
    {"TIMEZONENAME": "OTHER", "TIMEZONESHORTNAME": "OTHER", "TimeZoneUTCOffset": "OTHER"},
    {"TIMEZONENAME": "UNKNOWN", "TIMEZONESHORTNAME": "UNKN", "TimeZoneUTCOffset": "UNKNOWN"},
    {"TIMEZONENAME": "Dateline Standard Time", "TIMEZONESHORTNAME": "BIT", "TimeZoneUTCOffset": "-12:00"},
    {"TIMEZONENAME": "UTC-11", "TIMEZONESHORTNAME": "SST", "TimeZoneUTCOffset": "-11:00"},
    {"TIMEZONENAME": "Hawaiian Standard Time", "TIMEZONESHORTNAME": "HST", "TimeZoneUTCOffset": "-10:00"},
    {"TIMEZONENAME": "Marquesas Standard Time", "TIMEZONESHORTNAME": "MIT", "TimeZoneUTCOffset": "-09:30"},
    {"TIMEZONENAME": "Alaskan Standard Time", "TIMEZONESHORTNAME": "AKST", "TimeZoneUTCOffset": "-09:00"},
    {"TIMEZONENAME": "Pacific Standard Time", "TIMEZONESHORTNAME": "PST", "TimeZoneUTCOffset": "-08:00"},
    {"TIMEZONENAME": "Mountain Standard Time", "TIMEZONESHORTNAME": "MST", "TimeZoneUTCOffset": "-07:00"},
    {"TIMEZONENAME": "Canada Central Standard Time", "TIMEZONESHORTNAME": "CST", "TimeZoneUTCOffset": "-06:00"},
    {"TIMEZONENAME": "Eastern Standard Time", "TIMEZONESHORTNAME": "EST", "TimeZoneUTCOffset": "-05:00"},
    {"TIMEZONENAME": "Atlantic Standard Time", "TIMEZONESHORTNAME": "AST", "TimeZoneUTCOffset": "-04:00"},
    {"TIMEZONENAME": "Newfoundland Standard Time", "TIMEZONESHORTNAME": "NST", "TimeZoneUTCOffset": "-03:30"},
    {"TIMEZONENAME": "UTC-02", "TIMEZONESHORTNAME": "GST", "TimeZoneUTCOffset": "-02:00"},
    {"TIMEZONENAME": "Azores Standard Time", "TIMEZONESHORTNAME": "AZOT", "TimeZoneUTCOffset": "-01:00"},
    {"TIMEZONENAME": "Greenwich Standard Time", "TIMEZONESHORTNAME": "GMT", "TimeZoneUTCOffset": "+00:00"},
    {"TIMEZONENAME": "Central Europe Standard Time", "TIMEZONESHORTNAME": "CST", "TimeZoneUTCOffset": "+01:00"},
    {"TIMEZONENAME": "Israel Standard Time", "TIMEZONESHORTNAME": "IST", "TimeZoneUTCOffset": "+02:00"},
    {"TIMEZONENAME": "E. Africa Standard Time", "TIMEZONESHORTNAME": "EAT", "TimeZoneUTCOffset": "+03:00"},
    {"TIMEZONENAME": "Iran Standard Time", "TIMEZONESHORTNAME": "IRST", "TimeZoneUTCOffset": "+03:30"},
    {"TIMEZONENAME": "Georgian Standard Time", "TIMEZONESHORTNAME": "GET", "TimeZoneUTCOffset": "+04:00"},
    {"TIMEZONENAME": "Afghanistan Standard Time", "TIMEZONESHORTNAME": "AFT", "TimeZoneUTCOffset": "+04:30"},
    {"TIMEZONENAME": "India Standard Time", "TIMEZONESHORTNAME": "IST", "TimeZoneUTCOffset": "+05:30"},
    {"TIMEZONENAME": "Pakistan Standard Time", "TIMEZONESHORTNAME": "PKT", "TimeZoneUTCOffset": "+05:00"},
    {"TIMEZONENAME": "Bangladesh Standard Time", "TIMEZONESHORTNAME": "BST", "TimeZoneUTCOffset": "+06:00"},
    {"TIMEZONENAME": "North Asia Standard Time", "TIMEZONESHORTNAME": "CXT", "TimeZoneUTCOffset": "+07:00"},
    {"TIMEZONENAME": "China Standard Time", "TIMEZONESHORTNAME": "CST", "TimeZoneUTCOffset": "+08:00"},
    {"TIMEZONENAME": "Tokyo Standard Time", "TIMEZONESHORTNAME": "JST", "TimeZoneUTCOffset": "+09:00"},
    {"TIMEZONENAME": "AUS Central Standard Time", "TIMEZONESHORTNAME": "ACST", "TimeZoneUTCOffset": "+09:30"},
    {"TIMEZONENAME": "E. Australia Standard Time", "TIMEZONESHORTNAME": "AEST", "TimeZoneUTCOffset": "+10:00"},
    {"TIMEZONENAME": "AUS Eastern Standard Time", "TIMEZONESHORTNAME": "AEDT", "TimeZoneUTCOffset": "+11:00"},
    {"TIMEZONENAME": "Fiji Standard Time", "TIMEZONESHORTNAME": "FJT", "TimeZoneUTCOffset": "+12:00"},
    {"TIMEZONENAME": "New Zealand Standard Time", "TIMEZONESHORTNAME": "NZDT", "TimeZoneUTCOffset": "+13:00"},
    {"TIMEZONENAME": "Line Islands Standard Time", "TIMEZONESHORTNAME": "LINT", "TimeZoneUTCOffset": "+14:00"},
]

TIME_ZONE_NAMES = [tz["TIMEZONENAME"] for tz in TIME_ZONE_OPTIONS]