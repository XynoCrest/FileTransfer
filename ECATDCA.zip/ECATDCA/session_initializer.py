from snowflake.snowpark import Session

def retrieve_session():
    connection_parameters = {
        "account": "SUNCOR-ENTERPRISEDATA",
        "user": "C1.BSAHA@SUNCOR.ONMICROSOFT.COM",
        "authenticator": "externalbrowser",
        "database": "DP_DATACAPTURE_QUT",
        "schema": "ECAT",
        "warehouse": "WHS_COSTTRANSPARENCY",
        "role": "RG-APP-SF-DIS-DEVELOPER",
    }
    session = Session.builder.configs(connection_parameters).create()
    return session