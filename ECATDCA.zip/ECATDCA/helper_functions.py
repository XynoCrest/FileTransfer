import pandas as pd
import streamlit as st
from datetime import datetime

from constants import (
    TABLE_NAME,
    TIME_ZONE_OPTIONS,
    HIDDEN_COLUMNS
)

def retrieve_data(table_name):
    df = st.session_state.session.sql(f"SELECT * FROM {table_name}").to_pandas()
    df['TERMINALPROFILESID'] = pd.to_numeric(df['TERMINALPROFILESID'], errors='coerce')
    df['READER'] = df['READER'].astype(str)
    df['TERMINALTYPE'] = df['TERMINALTYPE'].astype(str)
    df['LOCATION'] = df['LOCATION'].astype(str)
    df['TIMEZONESHORTNAME'] = df['TIMEZONESHORTNAME'].astype(str)
    df['TIMEZONENAME'] = df['TIMEZONENAME'].astype(str)
    df['COUNTSFORSITE'] = pd.to_numeric(df['COUNTSFORSITE'], errors='coerce')
    df['TIMEATT'] = pd.to_numeric(df['TIMEATT'], errors='coerce')
    df['BUSINESSEFFECTIVESTARTDATE'] = pd.to_datetime(df['BUSINESSEFFECTIVESTARTDATE'], errors='coerce')
    df['BUSINESSEFFECTIVEENDDATE'] = pd.to_datetime(df['BUSINESSEFFECTIVEENDDATE'], errors='coerce')
    df['LATEARRIVINGFLAG'] = df['LATEARRIVINGFLAG'].astype(str)
    df['CREATEDDATETIME'] = pd.to_datetime(df['CREATEDDATETIME'], errors='coerce')
    df['CREATEDUSERID'] = df['CREATEDUSERID'].astype(str)
    df['LASTMODIFIEDDATETIME'] = pd.to_datetime(df['LASTMODIFIEDDATETIME'], errors='coerce')
    df['LASTMODIFIEDUSERID'] = df['LASTMODIFIEDUSERID'].astype(str)
    df['BATCHLOGID'] = pd.to_numeric(df['BATCHLOGID'], errors='coerce')
    return df

def get_changed_rows(
        df_old: pd.DataFrame,
        df_new: pd.DataFrame,
        compare_columns: list[str] = None,
        key_column: str = "TERMINALPROFILESID"
    ):
    """
    Compare two DataFrames and return:
    1) A styled DataFrame showing rows where selected columns differ,
        aligned by a key column, highlighting changed cells in yellow.
    
    2) The total number of changed cells.

    Returns
    -------
    tuple[styled_df, changed_count]
        styled_df : pandas.io.formats.style.Styler or None
            Styled DataFrame of changed rows (None if no changes found).
        changed_count : int
            Number of changed cells detected.
    """

    if compare_columns is None:
        compare_columns = [
            "TERMINALTYPE",
            "LOCATION",
            "TIMEZONENAME",
            "BUSINESSEFFECTIVESTARTDATE",
        ]

    # Ensure both DataFrames contain the key Column
    if key_column not in df_old.columns or key_column not in df_new.columns:
        raise ValueError(f"Both DataFrames must contain key column '{key_column}'")

    # Align both DataFrames on the key
    merged = pd.merge(
        df_old,
        df_new,
        on=key_column,
        suffixes=("_old", "_new"),
        how="inner",
    )
    merged = merged.drop(columns=HIDDEN_COLUMNS)

    # Find changed rows
    diff_mask = pd.DataFrame(False, index=merged.index, columns=compare_columns)
    for col in compare_columns:
        diff_mask[col] = merged[f"{col}_old"] != merged[f"{col}_new"]

    # Count total changed cells
    changed_count = int(diff_mask.sum().sum())

    # Get indices for changed rows
    changed_rows_mask = diff_mask.any(axis=1)

    # If no changes then return None and count = 0
    if not changed_rows_mask.any():
        return None, 0

    # Create a display DataFrame containing only the changed rows
    changed_df = df_new[df_new[key_column].isin(merged.loc[changed_rows_mask, key_column])].copy()
    changed_df = changed_df.drop(columns=HIDDEN_COLUMNS)

    # Function to create highlights of changed cell
    def highlight_changes(row_idx, col_name):
        id_val = changed_df.loc[row_idx, key_column]
        if col_name in compare_columns:
            old_val = df_old.loc[df_old[key_column] == id_val, col_name].values
            new_val = df_new.loc[df_new[key_column] == id_val, col_name].values
            if len(old_val) and len(new_val) and (old_val[0] != new_val[0]):
                return "background-color: MidnightBlue;"
        return ""

    def style_func(df):
        styles = pd.DataFrame("", index=df.index, columns=df.columns)
        for r in df.index:
            for c in df.columns:
                styles.loc[r, c] = highlight_changes(r, c)
        return styles

    styled = changed_df.style.apply(style_func, axis=None)
    return styled, changed_count

def promote_changes_to_updated_df(filtered_df, updated_df, key_column="TERMINALPROFILESID"):
    updated_master = updated_df.copy()
    updated_master.set_index(key_column, inplace=True)
    filtered_df.set_index(key_column, inplace=True)
    updated_master.update(filtered_df)
    updated_master.reset_index(inplace=True)
    return updated_master

def generate_changed_df(
        original_df: pd.DataFrame,
        uploaded_df: pd.DataFrame,
        editable_columns: list = None,
        key_columns: list = ["TERMINALPROFILESID"]
    ) -> pd.DataFrame:
    """
    Merge two DataFrames based on key columns, updating specified editable columns
    from uploaded_df while preserving all other columns from original_df.

    Parameters
    ----------
    original_df : pd.DataFrame
        The original DataFrame.
    uploaded_df : pd.DataFrame
        The uploaded DataFrame containing updated editable columns.
    editable_columns : list of str
        The names of columns whose values should come from uploaded_df.
    key_columns : list of str
        The names of columns to use for matching rows between the DataFrames.

    Returns
    -------
    pd.DataFrame
        A DataFrame containing only matched rows, with editable columns updated
        from uploaded_df and all other columns from original_df.
    """
    if editable_columns is None:
        editable_columns = [
            "TERMINALTYPE",
            "LOCATION",
            "TIMEZONENAME",
            "BUSINESSEFFECTIVESTARTDATE",
        ]

    # Perform an inner merge to retain only matching rows in both DataFrames
    merged_df = pd.merge(
        original_df,
        uploaded_df[key_columns + editable_columns],
        on=key_columns,
        how='inner',
        suffixes=('_orig', '_upload')
    )

    # For editable columns, use values from the uploaded_df
    for col in editable_columns:
        merged_df[col] = merged_df[f"{col}_upload"]

    # Drop auxiliary columns (_orig, _upload) for editable ones
    drop_cols = [f"{col}_upload" for col in editable_columns] + [f"{col}_orig" for col in editable_columns if f"{col}_orig" in merged_df.columns]
    merged_df = merged_df.drop(columns=drop_cols, errors='ignore')

    # Clean column names if any duplicates remain
    merged_df.columns = [col.replace('_orig', '') for col in merged_df.columns]

    # Fix column order to match original_df
    merged_df = merged_df[original_df.columns.intersection(merged_df.columns)]

    return merged_df


def dynamic_input_data_editor(data, key, **_kwargs):
    """
    Like streamlit's data_editor but which allows you to initialize the data editor with input arguments that can
    change between consecutive runs. Fixes the problem described here: https://discuss.streamlit.io/t/data-editor-not-changing-cell-the-1st-time-but-only-after-the-second-time/64894/13?u=ranyahalom
    :param data: The `data` argument you normally pass to `st.data_editor()`.
    :param key: The `key` argument you normally pass to `st.data_editor()`.
    :param _kwargs: All other named arguments you normally pass to `st.data_editor()`.
    :return: Same result returned by calling `st.data_editor()`
    """
    changed_key = f'{key}_khkhkkhkkhkhkihsdhsaskskhhfgiolwmxkahs'
    initial_data_key = f'{key}_khkhkkhkkhkhkihsdhsaskskhhfgiolwmxkahs__initial_data'

    def on_data_editor_changed():
        if 'on_change' in _kwargs:
            args = _kwargs['args'] if 'args' in _kwargs else ()
            kwargs = _kwargs['kwargs'] if 'kwargs' in _kwargs else  {}
            _kwargs['on_change'](*args, **kwargs)
        st.session_state[changed_key] = True

    if changed_key in st.session_state and st.session_state[changed_key]:
        data = st.session_state[initial_data_key]
        st.session_state[changed_key] = False
    else:
        st.session_state[initial_data_key] = data
    __kwargs = _kwargs.copy()
    __kwargs.update({'data': data, 'key': key, 'on_change': on_data_editor_changed})
    return st.data_editor(**__kwargs)


def get_timezone_shortname(timezone_name: str) -> str | None:
    """
    Given a TIMEZONENAME, return the corresponding TIMEZONESHORTNAME,
    or None if not found.
    """
    for tz in TIME_ZONE_OPTIONS:
        if tz["TIMEZONENAME"] == timezone_name:
            return tz["TIMEZONESHORTNAME"]
    return None

def handle_reload():
    st.session_state.dataframe = retrieve_data(TABLE_NAME)
    st.session_state.change_accumulated_df = st.session_state.dataframe
    st.session_state.changed_df = None
    st.session_state.filtered_df = None
    st.session_state.change_count = 0
    st.session_state.dataeditor_key = None
    st.rerun()

def display_error(error, error_definition, icon=':material/emergency_home:'):
    '''
    Only Show important part of the Error

    Example - 
    Original Error - (1304): 01c0642e-0107-47be-0002-24723bcb02aa: 090236 (42601): Stored procedure execution error: Unsupported statement type 'ALTER_SESSION'.

    Displayed Error - [error_definition]: Stored procedure execution error: Unsupported statement type 'ALTER_SESSION'.
    '''
    e = str(error)
    idx = e.rfind("):")
    if idx != -1:
        error_message = e[idx+2:].strip()
    else:
        error_message = e
    st.error(f'**{error_definition}**: {error_message}', icon=icon) 


def save_data(df):
    df = df.data
    show_success = True
    with st.session_state.save_bottom_container:
        try:
            with st.status('Saving Data') as status:
                with st.spinner('EXECUTING QUERIES IN :blue[**SNOWFLAKE**]', show_time=True):
                    for row in df.itertuples(index=False):
                        status.update(label=f"SAVING `TERMINALPROFILESID - {row.TERMINALPROFILESID}`")
                        query = f"""UPDATE {TABLE_NAME}
                    SET TERMINALTYPE = '{row.TERMINALTYPE}',
                        LOCATION = '{row.LOCATION}',
                        TIMEZONENAME = '{row.TIMEZONENAME}',
                        TIMEZONESHORTNAME = '{get_timezone_shortname(row.TIMEZONENAME)}',
                        BUSINESSEFFECTIVESTARTDATE = '{row.BUSINESSEFFECTIVESTARTDATE}',
                        LASTMODIFIEDDATETIME = '{datetime.now()}'
                    WHERE TERMINALPROFILESID = {row.TERMINALPROFILESID};
                        """
                        st.session_state.session.sql(query).collect()
        except Exception as e:
            with st.session_state.save_bottom_container:
                display_error(e, 'SAVE FAILED')
                show_success = False
        if show_success:
            print('Successfully Saved!')
            handle_reload()