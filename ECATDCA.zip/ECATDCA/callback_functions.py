import streamlit as st

def trigger_upload_verification():
    st.session_state.upload_verification= True
    return

def trigger_change_tracking():
    st.session_state.change_tracking = True
    return

