import streamlit as st
from session_initializer import retrieve_session
from datetime import datetime

from constants import (
    TABLE_NAME
)

from helper_functions import (
    retrieve_data
)

def initialize_state():
    if 'loading_container' not in st.session_state:
        st.session_state.loading_container = st.empty()

    if 'session' not in st.session_state:
        with st.session_state.loading_container.status('Initiating Session ...'):
            st.session_state.session = retrieve_session()
        st.session_state.loading_container.empty()
            
    if 'dataframe' not in st.session_state:
        with st.session_state.loading_container.status('Loading Data ...'):
            st.session_state.dataframe = retrieve_data(TABLE_NAME)
        st.session_state.loading_container.empty()

    # Manually rerun the app after critical state initiation to fix UI duplication effect
    if 'rerun_once' not in st.session_state:
        st.session_state.rerun_once = True
        st.rerun()

    if 'change_accumulated_df' not in st.session_state:
        st.session_state.change_accumulated_df = st.session_state.dataframe

    if 'dataeditor_key' not in st.session_state or st.session_state.dataeditor_key is None:
        st.session_state.dataeditor_key = f'ECAT_TERMINALPROFILE_{datetime.now()}'

    # Used as an if condition to trigger verification of file content after an upload event
    # Toggled through the file uploader callback
    if 'upload_verfication' not in st.session_state:
        st.session_state.upload_verification= False

    # Used to save the value of the filtered Df and make it persist across script reruns
    if 'filtered_df' not in st.session_state:
        st.session_state.filtered_df = None
    
    # Used as an if condition to trigger change tracking after the table is updated
    if 'change_tracking' not in st.session_state:
        st.session_state.change_tracking = False
    
    # Used to save the value of the changed Df and make it persist across script reruns
    if 'changed_df' not in st.session_state:
        st.session_state.changed_df = None
    
    # Used to save the value of the changed Df and make it persist across script reruns
    if 'changed_bulk_df' not in st.session_state:
        st.session_state.changed_bulk_df = None
    
    # Variable to store the number of changes made in total 
    if 'change_count' not in st.session_state:
        st.session_state.change_count = 0

    # Variable to store the number of changes made in total 
    if 'change_bulk_count' not in st.session_state:
        st.session_state.change_bulk_count = 0
    
    # Variable to store the dataframe uploaded by the user
    if 'uploaded_df' not in st.session_state:
        st.session_state.uploaded_df = None