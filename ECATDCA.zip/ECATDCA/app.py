import streamlit as st
import pandas as pd
from state_manager import initialize_state
from constants import (
    TERMINALTYPE_OPTIONS,
    TIME_ZONE_NAMES,
    HIDDEN_COLUMNS,
)

from callback_functions import (
    trigger_upload_verification,
    trigger_change_tracking
)

from helper_functions import (
    save_data,
    get_changed_rows,
    promote_changes_to_updated_df,
    generate_changed_df,
    dynamic_input_data_editor,
    handle_reload,
)

# ---------------------------------------------
# Page Config and Session State Initialization
# ---------------------------------------------
st.set_page_config(layout='wide')

# -----------------------
# Start of UI Elements
# -----------------------
st.title(':blue[ECA TERMINAL PROFILES]')
st.write('Manage and Edit ECA Terminal Profiles directly from within Snowflake! Only Columns with an :blue[:material/edit_note:] icon in their heading are Editable!')

initialize_state()

# -----------------------
# DataFrame Top Bar
# -----------------------
col1, col2, _, col3 = st.columns([5,5,4,5], vertical_alignment='bottom')

with col1:
    columns_filter = st.selectbox(
        'Column Filter', 
        ['TERMINALPROFILESID', 'READER', 'TERMINALTYPE', 'LOCATION', 'TIMEZONENAME'],
        label_visibility='hidden',
        index=None,
        placeholder='SELECT A COLUMN TO FILTER ON',
    )

with col2:
    filter_value = st.text_input(
        'filter_value',
        key='column_filter_value',
        label_visibility='hidden',
        placeholder='Filter Value'
    )
    
    if columns_filter and filter_value:
        st.session_state.filtered_df = st.session_state.change_accumulated_df[
            st.session_state.change_accumulated_df[columns_filter]
                .astype(str)
                .str.lower()
                .str.contains(filter_value.lower(), na=False)
        ]
    else:
        st.session_state.filtered_df = st.session_state.change_accumulated_df

with col3:
    with st.container():
        with st.container(horizontal_alignment='right', vertical_alignment='top', gap=None):
            csv = st.session_state.filtered_df.to_csv(index=False).encode("utf-8")

            st.download_button(
                f'Download — :blue[**{len(st.session_state.filtered_df):,} Records**]',
                icon=':material/download:',
                width=300,
                data=csv,
                file_name="TerminalProfiles.csv",
                mime="text/csv",
            )


# -----------------------
# Data Editor
# -----------------------
column_config= {
    'TERMINALPROFILESID': st.column_config.TextColumn(
        label='TERMINALPROFILESID',
        disabled=True
    ),

    'READER': st.column_config.TextColumn(
        label='READER',
        disabled=True
    ),

    'TERMINALTYPE': st.column_config.SelectboxColumn(
        label='TERMINALTYPE',
        options=TERMINALTYPE_OPTIONS,
        required=True,
    ),

    'LOCATION': st.column_config.TextColumn(
        label='LOCATION'
    ),

    'TIMEZONENAME': st.column_config.SelectboxColumn(
        label='TIMEZONENAME',
        options=TIME_ZONE_NAMES,
        required=True,
    ),

    'BUSINESSEFFECTIVESTARTDATE': st.column_config.DatetimeColumn(
        label='BUSINESSEFFECTIVESTARTDATE',
        required=True,
        format="YYYY-MM-DD"
    ),

    'BUSINESSEFFECTIVEENDDATE': st.column_config.DatetimeColumn(
        label='BUSINESSEFFECTIVEENDDATE',
        required=True,
        format="YYYY-MM-DD",
        disabled=True
    ),
    
    'LASTMODIFIEDDATETIME': st.column_config.DatetimeColumn(
        label='LASTMODIFIEDDATETIME',
        required=True,
        disabled=True
    ),
    
    'LASTMODIFIEDUSERID': st.column_config.TextColumn(
        label='LASTMODIFIEDUSERID',
        disabled=True
    )
}

updated_df = dynamic_input_data_editor(
    st.session_state.filtered_df.drop(columns=HIDDEN_COLUMNS),
    hide_index=True,
    column_config=column_config,
    key=st.session_state.dataeditor_key,
    on_change=trigger_change_tracking
)


if updated_df is not None and not updated_df.empty and st.session_state.change_tracking:
    st.session_state.change_tracking = False
    st.session_state.change_accumulated_df = promote_changes_to_updated_df(updated_df, st.session_state.change_accumulated_df)
    st.session_state.changed_df, st.session_state.change_count = get_changed_rows(st.session_state.dataframe.drop(columns=HIDDEN_COLUMNS), st.session_state.change_accumulated_df)

if st.session_state.changed_df is not None:
    with st.expander('Changed Data', icon=':material/database:'):
        st.subheader(':gray[Updated Rows]')
        st.markdown(":red-badge[🔴 **NO CHANGES ARE COMMITTED UNTIL YOU HIT SAVE!**] :blue-badge[ℹ️ **CHANGED CELLS ARE HIGHLIGHTED IN BlUE!**]")
        st.dataframe(
            st.session_state.changed_df,
            hide_index=True
        )

# -----------------------
# Data Editor Bottom Bar
# -----------------------
col1, col2, _, col3 = st.columns([4,2,2,10])

with col1:
    st.text_input(
        'Changes',
        label_visibility='collapsed',
        disabled=True,
        icon=':material/edit_square:',
        placeholder='NUMBER OF CHANGES'
    )

with col2:
    st.text_input(
        'change_number',
        value=st.session_state.change_count,
        label_visibility='collapsed',
        icon=':material/tag:',
        disabled=True,
    )

with col3:
    with st.container(horizontal_alignment='right', horizontal=True):
        save_popover = st.popover(
            'Save Changes',
            icon=':material/save:',
            width=250
        )

        with save_popover:
            with st.container(width=440, key='save_popover'):
                st.subheader(':yellow[:material/save: SAVE CHANGES]')
                st.caption('Are you sure you would like to save your changes?')
                
                if st.session_state.changed_df is not None and not st.session_state.changed_df.data.empty:
                    save_button_disabled = False
                    save_field_text = f'{st.session_state.change_count} changes will be Saved!'
                else:
                    save_button_disabled = True
                    save_field_text = 'You have no changes to save!'
                
                st.session_state.save_bottom_container = st.empty()
                
                with st.session_state.save_bottom_container:
                    col1, col2 = st.columns([4,2])
                    with col1:
                        st.text_input(
                            'change_number_save',
                            value=save_field_text,
                            label_visibility='collapsed',
                            icon=':material/tag:',
                            disabled=True,
                        )
                    with col2:
                        trigger_save = st.button(
                            'Save', 
                            icon=':material/save:',
                            width=160,  
                            key='save_changes',
                            disabled=save_button_disabled
                        )

            if trigger_save:
                save_data(st.session_state.changed_df)

        reload_popover = st.popover(
            'Reload Data',
            icon=':material/reset_settings:',
            width=250
        )

        with reload_popover:
            with st.container(width=440, key='reload_popover'):
                st.subheader(':red[:material/save: RELOAD TABLE]')
                st.caption('Are you sure you would like to Reload the Table?')
                col1, col2 = st.columns([4,2])
                with col1:
                    st.text_input(
                        'reload_number',
                        value=f'{st.session_state.change_count} changes will be Discarded!',
                        label_visibility='collapsed',
                        icon=':material/tag:',
                        disabled=True,
                    )
                with col2:
                    reload_table = st.button(
                        'Reload',
                        icon=':material/reset_settings:', 
                        width=160,  
                        key='reload_table'
                    )

        if reload_table:
            handle_reload()

st.markdown('')
st.markdown('')
st.markdown('')


# -----------------------
# File Uploader
# -----------------------
with st.container(border=True):
    st.header(':blue[:material/arrow_upload_progress: BULK UPLOAD PROFILES]')
    col1, col2 = st.columns([10,4], vertical_alignment='center')
    
    with col1:
        st.write('Mass Edit Existing Terminal Profiles by uploading a `.csv` or `.xlsx` file containing the updated records!')

    with col2:
        with st.container(horizontal_alignment='right'):
            save_popover_bulk = st.popover(
                'Save Changes',
                icon=':material/save:',
                width=250
            )

            with save_popover_bulk:
                with st.container(width=440, key='save_popover_bulk'):
                    st.subheader(':yellow[:material/save: SAVE CHANGES]')
                    st.caption('Are you sure you would like to save your changes?')
                    col1, col2 = st.columns([4,2])
                    with col1:
                        st.text_input(
                            'change_number_save_bulk',
                            value='43 Changes Detected!',
                            label_visibility='collapsed',
                            icon=':material/tag:',
                            disabled=True,
                        )
                    with col2:
                        trigger_save_bulk = st.button(
                            'Save', 
                            icon=':material/save:', 
                            width=160, 
                            key='save_changes_bulk'
                        )


    uploaded_file = st.file_uploader(
        "Upload your STTM",
        label_visibility="collapsed",
        on_change=trigger_upload_verification
    )

    if 'uploader_bottom_container' not in st.session_state:
        st.session_state.uploader_bottom_container = st.empty()
    
    if st.session_state.upload_verification:
        st.session_state.upload_verification = False
        
        if uploaded_file is not None:
            # Verify File Type
            file_extension = uploaded_file.name.split('.')[-1].strip()
            if file_extension == "xlsx":
                st.session_state.uploaded_df = pd.read_excel(uploaded_file)
            elif file_extension == "csv":
                st.session_state.uploaded_df = pd.read_csv(uploaded_file)
            
            else:
                st.session_state.uploader_bottom_container.error("Unsupported File Type! Please upload either a **.csv** or **.xlsx**", icon=":material/web_asset_off:")
                st.session_state.uploaded_df = None
        
            if st.session_state.uploaded_df is not None:
                bulk_changed_df = generate_changed_df(st.session_state.dataframe, st.session_state.uploaded_df)
                st.session_state.changed_bulk_df, st.session_state.change_bulk_count = get_changed_rows(st.session_state.dataframe, bulk_changed_df)
                
                if st.session_state.changed_bulk_df is not None and not st.session_state.changed_bulk_df.data.empty:
                    with st.session_state.uploader_bottom_container.expander('Changed Data', icon=':material/database_upload:'):
                        st.subheader(':gray[Updated Rows]')
                        st.markdown(":red-badge[🔴 **NO CHANGES ARE COMMITTED UNTIL YOU HIT SAVE!**] :blue-badge[ℹ️ **CHANGED CELLS ARE HIGHLIGHTED IN BlUE!**]")
                        st.dataframe(
                            st.session_state.changed_bulk_df,
                            hide_index=True
                        )
                else:
                    st.session_state.uploader_bottom_container.error('No changes to any Editable Columns Detected!', icon=':material/adjust:')
    else:
        st.session_state.uploader_bottom_container.caption('Updates made to **Editable Columns** will be **SAVED**! Changes made to **Non-Editable Columns** will be **IGNORED**! Any **Newly Inserted Rows** will be **DISCARDED**.')
